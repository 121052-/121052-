/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link CreditCards}.
 * </p>
 *
 * @author Shreeya
 * @see CreditCards
 * @generated
 */
public class CreditCardsWrapper implements CreditCards,
	ModelWrapper<CreditCards> {
	public CreditCardsWrapper(CreditCards creditCards) {
		_creditCards = creditCards;
	}

	@Override
	public Class<?> getModelClass() {
		return CreditCards.class;
	}

	@Override
	public String getModelClassName() {
		return CreditCards.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("cardNumber", getCardNumber());
		attributes.put("validFromDate", getValidFromDate());
		attributes.put("validToDate", getValidToDate());
		attributes.put("cvv", getCvv());
		attributes.put("nameOnCard", getNameOnCard());
		attributes.put("statementDate", getStatementDate());
		attributes.put("userId", getUserId());
		attributes.put("creditLimit", getCreditLimit());
		attributes.put("availableCreditLimit", getAvailableCreditLimit());
		attributes.put("royalty_points", getRoyalty_points());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String cardNumber = (String)attributes.get("cardNumber");

		if (cardNumber != null) {
			setCardNumber(cardNumber);
		}

		Date validFromDate = (Date)attributes.get("validFromDate");

		if (validFromDate != null) {
			setValidFromDate(validFromDate);
		}

		Date validToDate = (Date)attributes.get("validToDate");

		if (validToDate != null) {
			setValidToDate(validToDate);
		}

		Long cvv = (Long)attributes.get("cvv");

		if (cvv != null) {
			setCvv(cvv);
		}

		String nameOnCard = (String)attributes.get("nameOnCard");

		if (nameOnCard != null) {
			setNameOnCard(nameOnCard);
		}

		String statementDate = (String)attributes.get("statementDate");

		if (statementDate != null) {
			setStatementDate(statementDate);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Double creditLimit = (Double)attributes.get("creditLimit");

		if (creditLimit != null) {
			setCreditLimit(creditLimit);
		}

		Double availableCreditLimit = (Double)attributes.get(
				"availableCreditLimit");

		if (availableCreditLimit != null) {
			setAvailableCreditLimit(availableCreditLimit);
		}

		Integer royalty_points = (Integer)attributes.get("royalty_points");

		if (royalty_points != null) {
			setRoyalty_points(royalty_points);
		}
	}

	/**
	* Returns the primary key of this credit cards.
	*
	* @return the primary key of this credit cards
	*/
	@Override
	public long getPrimaryKey() {
		return _creditCards.getPrimaryKey();
	}

	/**
	* Sets the primary key of this credit cards.
	*
	* @param primaryKey the primary key of this credit cards
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_creditCards.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this credit cards.
	*
	* @return the uuid of this credit cards
	*/
	@Override
	public java.lang.String getUuid() {
		return _creditCards.getUuid();
	}

	/**
	* Sets the uuid of this credit cards.
	*
	* @param uuid the uuid of this credit cards
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_creditCards.setUuid(uuid);
	}

	/**
	* Returns the ID of this credit cards.
	*
	* @return the ID of this credit cards
	*/
	@Override
	public long getId() {
		return _creditCards.getId();
	}

	/**
	* Sets the ID of this credit cards.
	*
	* @param id the ID of this credit cards
	*/
	@Override
	public void setId(long id) {
		_creditCards.setId(id);
	}

	/**
	* Returns the card number of this credit cards.
	*
	* @return the card number of this credit cards
	*/
	@Override
	public java.lang.String getCardNumber() {
		return _creditCards.getCardNumber();
	}

	/**
	* Sets the card number of this credit cards.
	*
	* @param cardNumber the card number of this credit cards
	*/
	@Override
	public void setCardNumber(java.lang.String cardNumber) {
		_creditCards.setCardNumber(cardNumber);
	}

	/**
	* Returns the valid from date of this credit cards.
	*
	* @return the valid from date of this credit cards
	*/
	@Override
	public java.util.Date getValidFromDate() {
		return _creditCards.getValidFromDate();
	}

	/**
	* Sets the valid from date of this credit cards.
	*
	* @param validFromDate the valid from date of this credit cards
	*/
	@Override
	public void setValidFromDate(java.util.Date validFromDate) {
		_creditCards.setValidFromDate(validFromDate);
	}

	/**
	* Returns the valid to date of this credit cards.
	*
	* @return the valid to date of this credit cards
	*/
	@Override
	public java.util.Date getValidToDate() {
		return _creditCards.getValidToDate();
	}

	/**
	* Sets the valid to date of this credit cards.
	*
	* @param validToDate the valid to date of this credit cards
	*/
	@Override
	public void setValidToDate(java.util.Date validToDate) {
		_creditCards.setValidToDate(validToDate);
	}

	/**
	* Returns the cvv of this credit cards.
	*
	* @return the cvv of this credit cards
	*/
	@Override
	public long getCvv() {
		return _creditCards.getCvv();
	}

	/**
	* Sets the cvv of this credit cards.
	*
	* @param cvv the cvv of this credit cards
	*/
	@Override
	public void setCvv(long cvv) {
		_creditCards.setCvv(cvv);
	}

	/**
	* Returns the name on card of this credit cards.
	*
	* @return the name on card of this credit cards
	*/
	@Override
	public java.lang.String getNameOnCard() {
		return _creditCards.getNameOnCard();
	}

	/**
	* Sets the name on card of this credit cards.
	*
	* @param nameOnCard the name on card of this credit cards
	*/
	@Override
	public void setNameOnCard(java.lang.String nameOnCard) {
		_creditCards.setNameOnCard(nameOnCard);
	}

	/**
	* Returns the statement date of this credit cards.
	*
	* @return the statement date of this credit cards
	*/
	@Override
	public java.lang.String getStatementDate() {
		return _creditCards.getStatementDate();
	}

	/**
	* Sets the statement date of this credit cards.
	*
	* @param statementDate the statement date of this credit cards
	*/
	@Override
	public void setStatementDate(java.lang.String statementDate) {
		_creditCards.setStatementDate(statementDate);
	}

	/**
	* Returns the user ID of this credit cards.
	*
	* @return the user ID of this credit cards
	*/
	@Override
	public long getUserId() {
		return _creditCards.getUserId();
	}

	/**
	* Sets the user ID of this credit cards.
	*
	* @param userId the user ID of this credit cards
	*/
	@Override
	public void setUserId(long userId) {
		_creditCards.setUserId(userId);
	}

	/**
	* Returns the user uuid of this credit cards.
	*
	* @return the user uuid of this credit cards
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCards.getUserUuid();
	}

	/**
	* Sets the user uuid of this credit cards.
	*
	* @param userUuid the user uuid of this credit cards
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_creditCards.setUserUuid(userUuid);
	}

	/**
	* Returns the credit limit of this credit cards.
	*
	* @return the credit limit of this credit cards
	*/
	@Override
	public double getCreditLimit() {
		return _creditCards.getCreditLimit();
	}

	/**
	* Sets the credit limit of this credit cards.
	*
	* @param creditLimit the credit limit of this credit cards
	*/
	@Override
	public void setCreditLimit(double creditLimit) {
		_creditCards.setCreditLimit(creditLimit);
	}

	/**
	* Returns the available credit limit of this credit cards.
	*
	* @return the available credit limit of this credit cards
	*/
	@Override
	public double getAvailableCreditLimit() {
		return _creditCards.getAvailableCreditLimit();
	}

	/**
	* Sets the available credit limit of this credit cards.
	*
	* @param availableCreditLimit the available credit limit of this credit cards
	*/
	@Override
	public void setAvailableCreditLimit(double availableCreditLimit) {
		_creditCards.setAvailableCreditLimit(availableCreditLimit);
	}

	/**
	* Returns the royalty_points of this credit cards.
	*
	* @return the royalty_points of this credit cards
	*/
	@Override
	public int getRoyalty_points() {
		return _creditCards.getRoyalty_points();
	}

	/**
	* Sets the royalty_points of this credit cards.
	*
	* @param royalty_points the royalty_points of this credit cards
	*/
	@Override
	public void setRoyalty_points(int royalty_points) {
		_creditCards.setRoyalty_points(royalty_points);
	}

	@Override
	public boolean isNew() {
		return _creditCards.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_creditCards.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _creditCards.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_creditCards.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _creditCards.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _creditCards.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_creditCards.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _creditCards.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_creditCards.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_creditCards.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_creditCards.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new CreditCardsWrapper((CreditCards)_creditCards.clone());
	}

	@Override
	public int compareTo(com.ccm.model.CreditCards creditCards) {
		return _creditCards.compareTo(creditCards);
	}

	@Override
	public int hashCode() {
		return _creditCards.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.ccm.model.CreditCards> toCacheModel() {
		return _creditCards.toCacheModel();
	}

	@Override
	public com.ccm.model.CreditCards toEscapedModel() {
		return new CreditCardsWrapper(_creditCards.toEscapedModel());
	}

	@Override
	public com.ccm.model.CreditCards toUnescapedModel() {
		return new CreditCardsWrapper(_creditCards.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _creditCards.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _creditCards.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_creditCards.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CreditCardsWrapper)) {
			return false;
		}

		CreditCardsWrapper creditCardsWrapper = (CreditCardsWrapper)obj;

		if (Validator.equals(_creditCards, creditCardsWrapper._creditCards)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public CreditCards getWrappedCreditCards() {
		return _creditCards;
	}

	@Override
	public CreditCards getWrappedModel() {
		return _creditCards;
	}

	@Override
	public void resetOriginalValues() {
		_creditCards.resetOriginalValues();
	}

	private CreditCards _creditCards;
}