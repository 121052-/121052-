/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.ccm.service.ClpSerializer;
import com.ccm.service.CreditCardsLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Shreeya
 */
public class CreditCardsClp extends BaseModelImpl<CreditCards>
	implements CreditCards {
	public CreditCardsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return CreditCards.class;
	}

	@Override
	public String getModelClassName() {
		return CreditCards.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _id;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _id;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("cardNumber", getCardNumber());
		attributes.put("validFromDate", getValidFromDate());
		attributes.put("validToDate", getValidToDate());
		attributes.put("cvv", getCvv());
		attributes.put("nameOnCard", getNameOnCard());
		attributes.put("statementDate", getStatementDate());
		attributes.put("userId", getUserId());
		attributes.put("creditLimit", getCreditLimit());
		attributes.put("availableCreditLimit", getAvailableCreditLimit());
		attributes.put("royalty_points", getRoyalty_points());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String cardNumber = (String)attributes.get("cardNumber");

		if (cardNumber != null) {
			setCardNumber(cardNumber);
		}

		Date validFromDate = (Date)attributes.get("validFromDate");

		if (validFromDate != null) {
			setValidFromDate(validFromDate);
		}

		Date validToDate = (Date)attributes.get("validToDate");

		if (validToDate != null) {
			setValidToDate(validToDate);
		}

		Long cvv = (Long)attributes.get("cvv");

		if (cvv != null) {
			setCvv(cvv);
		}

		String nameOnCard = (String)attributes.get("nameOnCard");

		if (nameOnCard != null) {
			setNameOnCard(nameOnCard);
		}

		String statementDate = (String)attributes.get("statementDate");

		if (statementDate != null) {
			setStatementDate(statementDate);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Double creditLimit = (Double)attributes.get("creditLimit");

		if (creditLimit != null) {
			setCreditLimit(creditLimit);
		}

		Double availableCreditLimit = (Double)attributes.get(
				"availableCreditLimit");

		if (availableCreditLimit != null) {
			setAvailableCreditLimit(availableCreditLimit);
		}

		Integer royalty_points = (Integer)attributes.get("royalty_points");

		if (royalty_points != null) {
			setRoyalty_points(royalty_points);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_creditCardsRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getId() {
		return _id;
	}

	@Override
	public void setId(long id) {
		_id = id;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setId", long.class);

				method.invoke(_creditCardsRemoteModel, id);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCardNumber() {
		return _cardNumber;
	}

	@Override
	public void setCardNumber(String cardNumber) {
		_cardNumber = cardNumber;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setCardNumber", String.class);

				method.invoke(_creditCardsRemoteModel, cardNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getValidFromDate() {
		return _validFromDate;
	}

	@Override
	public void setValidFromDate(Date validFromDate) {
		_validFromDate = validFromDate;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setValidFromDate", Date.class);

				method.invoke(_creditCardsRemoteModel, validFromDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getValidToDate() {
		return _validToDate;
	}

	@Override
	public void setValidToDate(Date validToDate) {
		_validToDate = validToDate;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setValidToDate", Date.class);

				method.invoke(_creditCardsRemoteModel, validToDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCvv() {
		return _cvv;
	}

	@Override
	public void setCvv(long cvv) {
		_cvv = cvv;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setCvv", long.class);

				method.invoke(_creditCardsRemoteModel, cvv);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getNameOnCard() {
		return _nameOnCard;
	}

	@Override
	public void setNameOnCard(String nameOnCard) {
		_nameOnCard = nameOnCard;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setNameOnCard", String.class);

				method.invoke(_creditCardsRemoteModel, nameOnCard);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatementDate() {
		return _statementDate;
	}

	@Override
	public void setStatementDate(String statementDate) {
		_statementDate = statementDate;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setStatementDate", String.class);

				method.invoke(_creditCardsRemoteModel, statementDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_creditCardsRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public double getCreditLimit() {
		return _creditLimit;
	}

	@Override
	public void setCreditLimit(double creditLimit) {
		_creditLimit = creditLimit;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setCreditLimit", double.class);

				method.invoke(_creditCardsRemoteModel, creditLimit);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getAvailableCreditLimit() {
		return _availableCreditLimit;
	}

	@Override
	public void setAvailableCreditLimit(double availableCreditLimit) {
		_availableCreditLimit = availableCreditLimit;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setAvailableCreditLimit",
						double.class);

				method.invoke(_creditCardsRemoteModel, availableCreditLimit);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRoyalty_points() {
		return _royalty_points;
	}

	@Override
	public void setRoyalty_points(int royalty_points) {
		_royalty_points = royalty_points;

		if (_creditCardsRemoteModel != null) {
			try {
				Class<?> clazz = _creditCardsRemoteModel.getClass();

				Method method = clazz.getMethod("setRoyalty_points", int.class);

				method.invoke(_creditCardsRemoteModel, royalty_points);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getCreditCardsRemoteModel() {
		return _creditCardsRemoteModel;
	}

	public void setCreditCardsRemoteModel(BaseModel<?> creditCardsRemoteModel) {
		_creditCardsRemoteModel = creditCardsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _creditCardsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_creditCardsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			CreditCardsLocalServiceUtil.addCreditCards(this);
		}
		else {
			CreditCardsLocalServiceUtil.updateCreditCards(this);
		}
	}

	@Override
	public CreditCards toEscapedModel() {
		return (CreditCards)ProxyUtil.newProxyInstance(CreditCards.class.getClassLoader(),
			new Class[] { CreditCards.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		CreditCardsClp clone = new CreditCardsClp();

		clone.setUuid(getUuid());
		clone.setId(getId());
		clone.setCardNumber(getCardNumber());
		clone.setValidFromDate(getValidFromDate());
		clone.setValidToDate(getValidToDate());
		clone.setCvv(getCvv());
		clone.setNameOnCard(getNameOnCard());
		clone.setStatementDate(getStatementDate());
		clone.setUserId(getUserId());
		clone.setCreditLimit(getCreditLimit());
		clone.setAvailableCreditLimit(getAvailableCreditLimit());
		clone.setRoyalty_points(getRoyalty_points());

		return clone;
	}

	@Override
	public int compareTo(CreditCards creditCards) {
		long primaryKey = creditCards.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CreditCardsClp)) {
			return false;
		}

		CreditCardsClp creditCards = (CreditCardsClp)obj;

		long primaryKey = creditCards.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", id=");
		sb.append(getId());
		sb.append(", cardNumber=");
		sb.append(getCardNumber());
		sb.append(", validFromDate=");
		sb.append(getValidFromDate());
		sb.append(", validToDate=");
		sb.append(getValidToDate());
		sb.append(", cvv=");
		sb.append(getCvv());
		sb.append(", nameOnCard=");
		sb.append(getNameOnCard());
		sb.append(", statementDate=");
		sb.append(getStatementDate());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", creditLimit=");
		sb.append(getCreditLimit());
		sb.append(", availableCreditLimit=");
		sb.append(getAvailableCreditLimit());
		sb.append(", royalty_points=");
		sb.append(getRoyalty_points());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(40);

		sb.append("<model><model-name>");
		sb.append("com.ccm.model.CreditCards");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>id</column-name><column-value><![CDATA[");
		sb.append(getId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>cardNumber</column-name><column-value><![CDATA[");
		sb.append(getCardNumber());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>validFromDate</column-name><column-value><![CDATA[");
		sb.append(getValidFromDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>validToDate</column-name><column-value><![CDATA[");
		sb.append(getValidToDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>cvv</column-name><column-value><![CDATA[");
		sb.append(getCvv());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>nameOnCard</column-name><column-value><![CDATA[");
		sb.append(getNameOnCard());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statementDate</column-name><column-value><![CDATA[");
		sb.append(getStatementDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>creditLimit</column-name><column-value><![CDATA[");
		sb.append(getCreditLimit());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>availableCreditLimit</column-name><column-value><![CDATA[");
		sb.append(getAvailableCreditLimit());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>royalty_points</column-name><column-value><![CDATA[");
		sb.append(getRoyalty_points());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _id;
	private String _cardNumber;
	private Date _validFromDate;
	private Date _validToDate;
	private long _cvv;
	private String _nameOnCard;
	private String _statementDate;
	private long _userId;
	private String _userUuid;
	private double _creditLimit;
	private double _availableCreditLimit;
	private int _royalty_points;
	private BaseModel<?> _creditCardsRemoteModel;
	private Class<?> _clpSerializerClass = com.ccm.service.ClpSerializer.class;
}