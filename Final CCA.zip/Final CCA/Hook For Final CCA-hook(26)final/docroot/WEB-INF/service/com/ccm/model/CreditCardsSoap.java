/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.ccm.service.http.CreditCardsServiceSoap}.
 *
 * @author Shreeya
 * @see com.ccm.service.http.CreditCardsServiceSoap
 * @generated
 */
public class CreditCardsSoap implements Serializable {
	public static CreditCardsSoap toSoapModel(CreditCards model) {
		CreditCardsSoap soapModel = new CreditCardsSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setId(model.getId());
		soapModel.setCardNumber(model.getCardNumber());
		soapModel.setValidFromDate(model.getValidFromDate());
		soapModel.setValidToDate(model.getValidToDate());
		soapModel.setCvv(model.getCvv());
		soapModel.setNameOnCard(model.getNameOnCard());
		soapModel.setStatementDate(model.getStatementDate());
		soapModel.setUserId(model.getUserId());
		soapModel.setCreditLimit(model.getCreditLimit());
		soapModel.setAvailableCreditLimit(model.getAvailableCreditLimit());
		soapModel.setRoyalty_points(model.getRoyalty_points());

		return soapModel;
	}

	public static CreditCardsSoap[] toSoapModels(CreditCards[] models) {
		CreditCardsSoap[] soapModels = new CreditCardsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CreditCardsSoap[][] toSoapModels(CreditCards[][] models) {
		CreditCardsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CreditCardsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CreditCardsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CreditCardsSoap[] toSoapModels(List<CreditCards> models) {
		List<CreditCardsSoap> soapModels = new ArrayList<CreditCardsSoap>(models.size());

		for (CreditCards model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CreditCardsSoap[soapModels.size()]);
	}

	public CreditCardsSoap() {
	}

	public long getPrimaryKey() {
		return _id;
	}

	public void setPrimaryKey(long pk) {
		setId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getId() {
		return _id;
	}

	public void setId(long id) {
		_id = id;
	}

	public String getCardNumber() {
		return _cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		_cardNumber = cardNumber;
	}

	public Date getValidFromDate() {
		return _validFromDate;
	}

	public void setValidFromDate(Date validFromDate) {
		_validFromDate = validFromDate;
	}

	public Date getValidToDate() {
		return _validToDate;
	}

	public void setValidToDate(Date validToDate) {
		_validToDate = validToDate;
	}

	public long getCvv() {
		return _cvv;
	}

	public void setCvv(long cvv) {
		_cvv = cvv;
	}

	public String getNameOnCard() {
		return _nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		_nameOnCard = nameOnCard;
	}

	public String getStatementDate() {
		return _statementDate;
	}

	public void setStatementDate(String statementDate) {
		_statementDate = statementDate;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public double getCreditLimit() {
		return _creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		_creditLimit = creditLimit;
	}

	public double getAvailableCreditLimit() {
		return _availableCreditLimit;
	}

	public void setAvailableCreditLimit(double availableCreditLimit) {
		_availableCreditLimit = availableCreditLimit;
	}

	public int getRoyalty_points() {
		return _royalty_points;
	}

	public void setRoyalty_points(int royalty_points) {
		_royalty_points = royalty_points;
	}

	private String _uuid;
	private long _id;
	private String _cardNumber;
	private Date _validFromDate;
	private Date _validToDate;
	private long _cvv;
	private String _nameOnCard;
	private String _statementDate;
	private long _userId;
	private double _creditLimit;
	private double _availableCreditLimit;
	private int _royalty_points;
}