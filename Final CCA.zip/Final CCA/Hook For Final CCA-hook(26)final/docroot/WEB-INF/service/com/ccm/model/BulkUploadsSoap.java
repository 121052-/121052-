/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.ccm.service.http.BulkUploadsServiceSoap}.
 *
 * @author Shreeya
 * @see com.ccm.service.http.BulkUploadsServiceSoap
 * @generated
 */
public class BulkUploadsSoap implements Serializable {
	public static BulkUploadsSoap toSoapModel(BulkUploads model) {
		BulkUploadsSoap soapModel = new BulkUploadsSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setId(model.getId());
		soapModel.setUploadDate(model.getUploadDate());
		soapModel.setTimeTaken(model.getTimeTaken());
		soapModel.setTotalRecords(model.getTotalRecords());
		soapModel.setSuccessRecords(model.getSuccessRecords());
		soapModel.setFailedRecords(model.getFailedRecords());
		soapModel.setFileName(model.getFileName());
		soapModel.setErrorFilePath(model.getErrorFilePath());
		soapModel.setUserId(model.getUserId());
		soapModel.setCreditCardId(model.getCreditCardId());

		return soapModel;
	}

	public static BulkUploadsSoap[] toSoapModels(BulkUploads[] models) {
		BulkUploadsSoap[] soapModels = new BulkUploadsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static BulkUploadsSoap[][] toSoapModels(BulkUploads[][] models) {
		BulkUploadsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new BulkUploadsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new BulkUploadsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static BulkUploadsSoap[] toSoapModels(List<BulkUploads> models) {
		List<BulkUploadsSoap> soapModels = new ArrayList<BulkUploadsSoap>(models.size());

		for (BulkUploads model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new BulkUploadsSoap[soapModels.size()]);
	}

	public BulkUploadsSoap() {
	}

	public long getPrimaryKey() {
		return _id;
	}

	public void setPrimaryKey(long pk) {
		setId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getId() {
		return _id;
	}

	public void setId(long id) {
		_id = id;
	}

	public Date getUploadDate() {
		return _uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		_uploadDate = uploadDate;
	}

	public double getTimeTaken() {
		return _timeTaken;
	}

	public void setTimeTaken(double timeTaken) {
		_timeTaken = timeTaken;
	}

	public int getTotalRecords() {
		return _totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		_totalRecords = totalRecords;
	}

	public int getSuccessRecords() {
		return _successRecords;
	}

	public void setSuccessRecords(int successRecords) {
		_successRecords = successRecords;
	}

	public int getFailedRecords() {
		return _failedRecords;
	}

	public void setFailedRecords(int failedRecords) {
		_failedRecords = failedRecords;
	}

	public String getFileName() {
		return _fileName;
	}

	public void setFileName(String fileName) {
		_fileName = fileName;
	}

	public String getErrorFilePath() {
		return _errorFilePath;
	}

	public void setErrorFilePath(String errorFilePath) {
		_errorFilePath = errorFilePath;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public long getCreditCardId() {
		return _creditCardId;
	}

	public void setCreditCardId(long creditCardId) {
		_creditCardId = creditCardId;
	}

	private String _uuid;
	private long _id;
	private Date _uploadDate;
	private double _timeTaken;
	private int _totalRecords;
	private int _successRecords;
	private int _failedRecords;
	private String _fileName;
	private String _errorFilePath;
	private long _userId;
	private long _creditCardId;
}