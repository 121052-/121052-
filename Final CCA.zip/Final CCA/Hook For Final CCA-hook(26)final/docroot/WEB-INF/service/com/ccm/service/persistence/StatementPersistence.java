/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.persistence;

import com.ccm.model.Statement;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the statement service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Shreeya
 * @see StatementPersistenceImpl
 * @see StatementUtil
 * @generated
 */
public interface StatementPersistence extends BasePersistence<Statement> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link StatementUtil} to access the statement persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the statements where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the statements where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @return the range of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the statements where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first statement in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching statement
	* @throws com.ccm.NoSuchStatementException if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement findByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first statement in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching statement, or <code>null</code> if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement fetchByUuid_First(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last statement in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching statement
	* @throws com.ccm.NoSuchStatementException if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement findByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last statement in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching statement, or <code>null</code> if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement fetchByUuid_Last(java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the statements before and after the current statement in the ordered set where uuid = &#63;.
	*
	* @param id the primary key of the current statement
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next statement
	* @throws com.ccm.NoSuchStatementException if a statement with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement[] findByUuid_PrevAndNext(long id,
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the statements where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of statements where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the statements where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @return the matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByCreditCardId(
		long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the statements where creditCardId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param creditCardId the credit card ID
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @return the range of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByCreditCardId(
		long creditCardId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the statements where creditCardId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param creditCardId the credit card ID
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findByCreditCardId(
		long creditCardId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first statement in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching statement
	* @throws com.ccm.NoSuchStatementException if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement findByCreditCardId_First(long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first statement in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching statement, or <code>null</code> if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement fetchByCreditCardId_First(
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last statement in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching statement
	* @throws com.ccm.NoSuchStatementException if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement findByCreditCardId_Last(long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last statement in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching statement, or <code>null</code> if a matching statement could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement fetchByCreditCardId_Last(long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the statements before and after the current statement in the ordered set where creditCardId = &#63;.
	*
	* @param id the primary key of the current statement
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next statement
	* @throws com.ccm.NoSuchStatementException if a statement with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement[] findByCreditCardId_PrevAndNext(long id,
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the statements where creditCardId = &#63; from the database.
	*
	* @param creditCardId the credit card ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByCreditCardId(long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of statements where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @return the number of matching statements
	* @throws SystemException if a system exception occurred
	*/
	public int countByCreditCardId(long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the statement in the entity cache if it is enabled.
	*
	* @param statement the statement
	*/
	public void cacheResult(com.ccm.model.Statement statement);

	/**
	* Caches the statements in the entity cache if it is enabled.
	*
	* @param statements the statements
	*/
	public void cacheResult(java.util.List<com.ccm.model.Statement> statements);

	/**
	* Creates a new statement with the primary key. Does not add the statement to the database.
	*
	* @param id the primary key for the new statement
	* @return the new statement
	*/
	public com.ccm.model.Statement create(long id);

	/**
	* Removes the statement with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the statement
	* @return the statement that was removed
	* @throws com.ccm.NoSuchStatementException if a statement with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement remove(long id)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.ccm.model.Statement updateImpl(com.ccm.model.Statement statement)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the statement with the primary key or throws a {@link com.ccm.NoSuchStatementException} if it could not be found.
	*
	* @param id the primary key of the statement
	* @return the statement
	* @throws com.ccm.NoSuchStatementException if a statement with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement findByPrimaryKey(long id)
		throws com.ccm.NoSuchStatementException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the statement with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param id the primary key of the statement
	* @return the statement, or <code>null</code> if a statement with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.ccm.model.Statement fetchByPrimaryKey(long id)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the statements.
	*
	* @return the statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the statements.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @return the range of statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findAll(int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the statements.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.StatementModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of statements
	* @param end the upper bound of the range of statements (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of statements
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.ccm.model.Statement> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the statements from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of statements.
	*
	* @return the number of statements
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}