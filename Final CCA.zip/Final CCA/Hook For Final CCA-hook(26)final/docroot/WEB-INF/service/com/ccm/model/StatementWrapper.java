/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Statement}.
 * </p>
 *
 * @author Shreeya
 * @see Statement
 * @generated
 */
public class StatementWrapper implements Statement, ModelWrapper<Statement> {
	public StatementWrapper(Statement statement) {
		_statement = statement;
	}

	@Override
	public Class<?> getModelClass() {
		return Statement.class;
	}

	@Override
	public String getModelClassName() {
		return Statement.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("creditCardId", getCreditCardId());
		attributes.put("statementDate", getStatementDate());
		attributes.put("fromDate", getFromDate());
		attributes.put("toDate", getToDate());
		attributes.put("amountDue", getAmountDue());
		attributes.put("statementFilePath", getStatementFilePath());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Long creditCardId = (Long)attributes.get("creditCardId");

		if (creditCardId != null) {
			setCreditCardId(creditCardId);
		}

		Date statementDate = (Date)attributes.get("statementDate");

		if (statementDate != null) {
			setStatementDate(statementDate);
		}

		Date fromDate = (Date)attributes.get("fromDate");

		if (fromDate != null) {
			setFromDate(fromDate);
		}

		Date toDate = (Date)attributes.get("toDate");

		if (toDate != null) {
			setToDate(toDate);
		}

		Double amountDue = (Double)attributes.get("amountDue");

		if (amountDue != null) {
			setAmountDue(amountDue);
		}

		String statementFilePath = (String)attributes.get("statementFilePath");

		if (statementFilePath != null) {
			setStatementFilePath(statementFilePath);
		}
	}

	/**
	* Returns the primary key of this statement.
	*
	* @return the primary key of this statement
	*/
	@Override
	public long getPrimaryKey() {
		return _statement.getPrimaryKey();
	}

	/**
	* Sets the primary key of this statement.
	*
	* @param primaryKey the primary key of this statement
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_statement.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this statement.
	*
	* @return the uuid of this statement
	*/
	@Override
	public java.lang.String getUuid() {
		return _statement.getUuid();
	}

	/**
	* Sets the uuid of this statement.
	*
	* @param uuid the uuid of this statement
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_statement.setUuid(uuid);
	}

	/**
	* Returns the ID of this statement.
	*
	* @return the ID of this statement
	*/
	@Override
	public long getId() {
		return _statement.getId();
	}

	/**
	* Sets the ID of this statement.
	*
	* @param id the ID of this statement
	*/
	@Override
	public void setId(long id) {
		_statement.setId(id);
	}

	/**
	* Returns the credit card ID of this statement.
	*
	* @return the credit card ID of this statement
	*/
	@Override
	public long getCreditCardId() {
		return _statement.getCreditCardId();
	}

	/**
	* Sets the credit card ID of this statement.
	*
	* @param creditCardId the credit card ID of this statement
	*/
	@Override
	public void setCreditCardId(long creditCardId) {
		_statement.setCreditCardId(creditCardId);
	}

	/**
	* Returns the statement date of this statement.
	*
	* @return the statement date of this statement
	*/
	@Override
	public java.util.Date getStatementDate() {
		return _statement.getStatementDate();
	}

	/**
	* Sets the statement date of this statement.
	*
	* @param statementDate the statement date of this statement
	*/
	@Override
	public void setStatementDate(java.util.Date statementDate) {
		_statement.setStatementDate(statementDate);
	}

	/**
	* Returns the from date of this statement.
	*
	* @return the from date of this statement
	*/
	@Override
	public java.util.Date getFromDate() {
		return _statement.getFromDate();
	}

	/**
	* Sets the from date of this statement.
	*
	* @param fromDate the from date of this statement
	*/
	@Override
	public void setFromDate(java.util.Date fromDate) {
		_statement.setFromDate(fromDate);
	}

	/**
	* Returns the to date of this statement.
	*
	* @return the to date of this statement
	*/
	@Override
	public java.util.Date getToDate() {
		return _statement.getToDate();
	}

	/**
	* Sets the to date of this statement.
	*
	* @param toDate the to date of this statement
	*/
	@Override
	public void setToDate(java.util.Date toDate) {
		_statement.setToDate(toDate);
	}

	/**
	* Returns the amount due of this statement.
	*
	* @return the amount due of this statement
	*/
	@Override
	public double getAmountDue() {
		return _statement.getAmountDue();
	}

	/**
	* Sets the amount due of this statement.
	*
	* @param amountDue the amount due of this statement
	*/
	@Override
	public void setAmountDue(double amountDue) {
		_statement.setAmountDue(amountDue);
	}

	/**
	* Returns the statement file path of this statement.
	*
	* @return the statement file path of this statement
	*/
	@Override
	public java.lang.String getStatementFilePath() {
		return _statement.getStatementFilePath();
	}

	/**
	* Sets the statement file path of this statement.
	*
	* @param statementFilePath the statement file path of this statement
	*/
	@Override
	public void setStatementFilePath(java.lang.String statementFilePath) {
		_statement.setStatementFilePath(statementFilePath);
	}

	@Override
	public boolean isNew() {
		return _statement.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_statement.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _statement.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_statement.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _statement.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _statement.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_statement.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _statement.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_statement.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_statement.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_statement.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new StatementWrapper((Statement)_statement.clone());
	}

	@Override
	public int compareTo(com.ccm.model.Statement statement) {
		return _statement.compareTo(statement);
	}

	@Override
	public int hashCode() {
		return _statement.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.ccm.model.Statement> toCacheModel() {
		return _statement.toCacheModel();
	}

	@Override
	public com.ccm.model.Statement toEscapedModel() {
		return new StatementWrapper(_statement.toEscapedModel());
	}

	@Override
	public com.ccm.model.Statement toUnescapedModel() {
		return new StatementWrapper(_statement.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _statement.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _statement.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_statement.persist();
	}

	@Override
	public java.lang.String getCardNumber() {
		return _statement.getCardNumber();
	}

	@Override
	public void setCustomerName(java.lang.String cardNumber) {
		_statement.setCustomerName(cardNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof StatementWrapper)) {
			return false;
		}

		StatementWrapper statementWrapper = (StatementWrapper)obj;

		if (Validator.equals(_statement, statementWrapper._statement)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Statement getWrappedStatement() {
		return _statement;
	}

	@Override
	public Statement getWrappedModel() {
		return _statement;
	}

	@Override
	public void resetOriginalValues() {
		_statement.resetOriginalValues();
	}

	private Statement _statement;
}