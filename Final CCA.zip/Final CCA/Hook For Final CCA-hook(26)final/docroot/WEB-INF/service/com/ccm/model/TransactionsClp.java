/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.ccm.service.ClpSerializer;
import com.ccm.service.TransactionsLocalServiceUtil;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Shreeya
 */
public class TransactionsClp extends BaseModelImpl<Transactions>
	implements Transactions {
	public TransactionsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Transactions.class;
	}

	@Override
	public String getModelClassName() {
		return Transactions.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _id;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _id;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("creditCardId", getCreditCardId());
		attributes.put("amount", getAmount());
		attributes.put("transactionDate", getTransactionDate());
		attributes.put("balance", getBalance());
		attributes.put("description", getDescription());
		attributes.put("userId", getUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Long creditCardId = (Long)attributes.get("creditCardId");

		if (creditCardId != null) {
			setCreditCardId(creditCardId);
		}

		Double amount = (Double)attributes.get("amount");

		if (amount != null) {
			setAmount(amount);
		}

		Date transactionDate = (Date)attributes.get("transactionDate");

		if (transactionDate != null) {
			setTransactionDate(transactionDate);
		}

		Double balance = (Double)attributes.get("balance");

		if (balance != null) {
			setBalance(balance);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_transactionsRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getId() {
		return _id;
	}

	@Override
	public void setId(long id) {
		_id = id;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setId", long.class);

				method.invoke(_transactionsRemoteModel, id);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCreditCardId() {
		return _creditCardId;
	}

	@Override
	public void setCreditCardId(long creditCardId) {
		_creditCardId = creditCardId;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setCreditCardId", long.class);

				method.invoke(_transactionsRemoteModel, creditCardId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getAmount() {
		return _amount;
	}

	@Override
	public void setAmount(double amount) {
		_amount = amount;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setAmount", double.class);

				method.invoke(_transactionsRemoteModel, amount);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getTransactionDate() {
		return _transactionDate;
	}

	@Override
	public void setTransactionDate(Date transactionDate) {
		_transactionDate = transactionDate;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setTransactionDate", Date.class);

				method.invoke(_transactionsRemoteModel, transactionDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getBalance() {
		return _balance;
	}

	@Override
	public void setBalance(double balance) {
		_balance = balance;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setBalance", double.class);

				method.invoke(_transactionsRemoteModel, balance);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_transactionsRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_transactionsRemoteModel != null) {
			try {
				Class<?> clazz = _transactionsRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_transactionsRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public void setCustomerName(java.lang.String customerName) {
		try {
			String methodName = "setCustomerName";

			Class<?>[] parameterTypes = new Class<?>[] { java.lang.String.class };

			Object[] parameterValues = new Object[] { customerName };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public java.lang.String getCustomerName() {
		try {
			String methodName = "getCustomerName";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			java.lang.String returnObj = (java.lang.String)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	public BaseModel<?> getTransactionsRemoteModel() {
		return _transactionsRemoteModel;
	}

	public void setTransactionsRemoteModel(BaseModel<?> transactionsRemoteModel) {
		_transactionsRemoteModel = transactionsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _transactionsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_transactionsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			TransactionsLocalServiceUtil.addTransactions(this);
		}
		else {
			TransactionsLocalServiceUtil.updateTransactions(this);
		}
	}

	@Override
	public Transactions toEscapedModel() {
		return (Transactions)ProxyUtil.newProxyInstance(Transactions.class.getClassLoader(),
			new Class[] { Transactions.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		TransactionsClp clone = new TransactionsClp();

		clone.setUuid(getUuid());
		clone.setId(getId());
		clone.setCreditCardId(getCreditCardId());
		clone.setAmount(getAmount());
		clone.setTransactionDate(getTransactionDate());
		clone.setBalance(getBalance());
		clone.setDescription(getDescription());
		clone.setUserId(getUserId());

		return clone;
	}

	@Override
	public int compareTo(Transactions transactions) {
		long primaryKey = transactions.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TransactionsClp)) {
			return false;
		}

		TransactionsClp transactions = (TransactionsClp)obj;

		long primaryKey = transactions.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", id=");
		sb.append(getId());
		sb.append(", creditCardId=");
		sb.append(getCreditCardId());
		sb.append(", amount=");
		sb.append(getAmount());
		sb.append(", transactionDate=");
		sb.append(getTransactionDate());
		sb.append(", balance=");
		sb.append(getBalance());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("com.ccm.model.Transactions");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>id</column-name><column-value><![CDATA[");
		sb.append(getId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>creditCardId</column-name><column-value><![CDATA[");
		sb.append(getCreditCardId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>amount</column-name><column-value><![CDATA[");
		sb.append(getAmount());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>transactionDate</column-name><column-value><![CDATA[");
		sb.append(getTransactionDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>balance</column-name><column-value><![CDATA[");
		sb.append(getBalance());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _id;
	private long _creditCardId;
	private double _amount;
	private Date _transactionDate;
	private double _balance;
	private String _description;
	private long _userId;
	private String _userUuid;
	private BaseModel<?> _transactionsRemoteModel;
	private Class<?> _clpSerializerClass = com.ccm.service.ClpSerializer.class;
}