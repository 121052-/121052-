/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Transactions}.
 * </p>
 *
 * @author Shreeya
 * @see Transactions
 * @generated
 */
public class TransactionsWrapper implements Transactions,
	ModelWrapper<Transactions> {
	public TransactionsWrapper(Transactions transactions) {
		_transactions = transactions;
	}

	@Override
	public Class<?> getModelClass() {
		return Transactions.class;
	}

	@Override
	public String getModelClassName() {
		return Transactions.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("creditCardId", getCreditCardId());
		attributes.put("amount", getAmount());
		attributes.put("transactionDate", getTransactionDate());
		attributes.put("balance", getBalance());
		attributes.put("description", getDescription());
		attributes.put("userId", getUserId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Long creditCardId = (Long)attributes.get("creditCardId");

		if (creditCardId != null) {
			setCreditCardId(creditCardId);
		}

		Double amount = (Double)attributes.get("amount");

		if (amount != null) {
			setAmount(amount);
		}

		Date transactionDate = (Date)attributes.get("transactionDate");

		if (transactionDate != null) {
			setTransactionDate(transactionDate);
		}

		Double balance = (Double)attributes.get("balance");

		if (balance != null) {
			setBalance(balance);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}
	}

	/**
	* Returns the primary key of this transactions.
	*
	* @return the primary key of this transactions
	*/
	@Override
	public long getPrimaryKey() {
		return _transactions.getPrimaryKey();
	}

	/**
	* Sets the primary key of this transactions.
	*
	* @param primaryKey the primary key of this transactions
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_transactions.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this transactions.
	*
	* @return the uuid of this transactions
	*/
	@Override
	public java.lang.String getUuid() {
		return _transactions.getUuid();
	}

	/**
	* Sets the uuid of this transactions.
	*
	* @param uuid the uuid of this transactions
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_transactions.setUuid(uuid);
	}

	/**
	* Returns the ID of this transactions.
	*
	* @return the ID of this transactions
	*/
	@Override
	public long getId() {
		return _transactions.getId();
	}

	/**
	* Sets the ID of this transactions.
	*
	* @param id the ID of this transactions
	*/
	@Override
	public void setId(long id) {
		_transactions.setId(id);
	}

	/**
	* Returns the credit card ID of this transactions.
	*
	* @return the credit card ID of this transactions
	*/
	@Override
	public long getCreditCardId() {
		return _transactions.getCreditCardId();
	}

	/**
	* Sets the credit card ID of this transactions.
	*
	* @param creditCardId the credit card ID of this transactions
	*/
	@Override
	public void setCreditCardId(long creditCardId) {
		_transactions.setCreditCardId(creditCardId);
	}

	/**
	* Returns the amount of this transactions.
	*
	* @return the amount of this transactions
	*/
	@Override
	public double getAmount() {
		return _transactions.getAmount();
	}

	/**
	* Sets the amount of this transactions.
	*
	* @param amount the amount of this transactions
	*/
	@Override
	public void setAmount(double amount) {
		_transactions.setAmount(amount);
	}

	/**
	* Returns the transaction date of this transactions.
	*
	* @return the transaction date of this transactions
	*/
	@Override
	public java.util.Date getTransactionDate() {
		return _transactions.getTransactionDate();
	}

	/**
	* Sets the transaction date of this transactions.
	*
	* @param transactionDate the transaction date of this transactions
	*/
	@Override
	public void setTransactionDate(java.util.Date transactionDate) {
		_transactions.setTransactionDate(transactionDate);
	}

	/**
	* Returns the balance of this transactions.
	*
	* @return the balance of this transactions
	*/
	@Override
	public double getBalance() {
		return _transactions.getBalance();
	}

	/**
	* Sets the balance of this transactions.
	*
	* @param balance the balance of this transactions
	*/
	@Override
	public void setBalance(double balance) {
		_transactions.setBalance(balance);
	}

	/**
	* Returns the description of this transactions.
	*
	* @return the description of this transactions
	*/
	@Override
	public java.lang.String getDescription() {
		return _transactions.getDescription();
	}

	/**
	* Sets the description of this transactions.
	*
	* @param description the description of this transactions
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_transactions.setDescription(description);
	}

	/**
	* Returns the user ID of this transactions.
	*
	* @return the user ID of this transactions
	*/
	@Override
	public long getUserId() {
		return _transactions.getUserId();
	}

	/**
	* Sets the user ID of this transactions.
	*
	* @param userId the user ID of this transactions
	*/
	@Override
	public void setUserId(long userId) {
		_transactions.setUserId(userId);
	}

	/**
	* Returns the user uuid of this transactions.
	*
	* @return the user uuid of this transactions
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _transactions.getUserUuid();
	}

	/**
	* Sets the user uuid of this transactions.
	*
	* @param userUuid the user uuid of this transactions
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_transactions.setUserUuid(userUuid);
	}

	@Override
	public boolean isNew() {
		return _transactions.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_transactions.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _transactions.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_transactions.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _transactions.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _transactions.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_transactions.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _transactions.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_transactions.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_transactions.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_transactions.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new TransactionsWrapper((Transactions)_transactions.clone());
	}

	@Override
	public int compareTo(com.ccm.model.Transactions transactions) {
		return _transactions.compareTo(transactions);
	}

	@Override
	public int hashCode() {
		return _transactions.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.ccm.model.Transactions> toCacheModel() {
		return _transactions.toCacheModel();
	}

	@Override
	public com.ccm.model.Transactions toEscapedModel() {
		return new TransactionsWrapper(_transactions.toEscapedModel());
	}

	@Override
	public com.ccm.model.Transactions toUnescapedModel() {
		return new TransactionsWrapper(_transactions.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _transactions.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _transactions.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_transactions.persist();
	}

	@Override
	public java.lang.String getCustomerName() {
		return _transactions.getCustomerName();
	}

	@Override
	public void setCustomerName(java.lang.String customerName) {
		_transactions.setCustomerName(customerName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TransactionsWrapper)) {
			return false;
		}

		TransactionsWrapper transactionsWrapper = (TransactionsWrapper)obj;

		if (Validator.equals(_transactions, transactionsWrapper._transactions)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Transactions getWrappedTransactions() {
		return _transactions;
	}

	@Override
	public Transactions getWrappedModel() {
		return _transactions;
	}

	@Override
	public void resetOriginalValues() {
		_transactions.resetOriginalValues();
	}

	private Transactions _transactions;
}