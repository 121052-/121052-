/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.persistence;

import com.ccm.model.BulkUploads;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the bulk uploads service. This utility wraps {@link BulkUploadsPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Shreeya
 * @see BulkUploadsPersistence
 * @see BulkUploadsPersistenceImpl
 * @generated
 */
public class BulkUploadsUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(BulkUploads bulkUploads) {
		getPersistence().clearCache(bulkUploads);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<BulkUploads> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<BulkUploads> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<BulkUploads> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static BulkUploads update(BulkUploads bulkUploads)
		throws SystemException {
		return getPersistence().update(bulkUploads);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static BulkUploads update(BulkUploads bulkUploads,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(bulkUploads, serviceContext);
	}

	/**
	* Returns all the bulk uploadses where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the bulk uploadses where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @return the range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the bulk uploadses where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the bulk uploadses before and after the current bulk uploads in the ordered set where uuid = &#63;.
	*
	* @param id the primary key of the current bulk uploads
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads[] findByUuid_PrevAndNext(long id,
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_PrevAndNext(id, uuid, orderByComparator);
	}

	/**
	* Removes all the bulk uploadses where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of bulk uploadses where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns all the bulk uploadses where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @return the matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByCreditCardId(
		long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCreditCardId(creditCardId);
	}

	/**
	* Returns a range of all the bulk uploadses where creditCardId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param creditCardId the credit card ID
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @return the range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByCreditCardId(
		long creditCardId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCreditCardId(creditCardId, start, end);
	}

	/**
	* Returns an ordered range of all the bulk uploadses where creditCardId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param creditCardId the credit card ID
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByCreditCardId(
		long creditCardId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCreditCardId(creditCardId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByCreditCardId_First(
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCreditCardId_First(creditCardId, orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByCreditCardId_First(
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCreditCardId_First(creditCardId, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByCreditCardId_Last(
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCreditCardId_Last(creditCardId, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByCreditCardId_Last(
		long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCreditCardId_Last(creditCardId, orderByComparator);
	}

	/**
	* Returns the bulk uploadses before and after the current bulk uploads in the ordered set where creditCardId = &#63;.
	*
	* @param id the primary key of the current bulk uploads
	* @param creditCardId the credit card ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads[] findByCreditCardId_PrevAndNext(
		long id, long creditCardId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCreditCardId_PrevAndNext(id, creditCardId,
			orderByComparator);
	}

	/**
	* Removes all the bulk uploadses where creditCardId = &#63; from the database.
	*
	* @param creditCardId the credit card ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByCreditCardId(long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByCreditCardId(creditCardId);
	}

	/**
	* Returns the number of bulk uploadses where creditCardId = &#63;.
	*
	* @param creditCardId the credit card ID
	* @return the number of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByCreditCardId(long creditCardId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByCreditCardId(creditCardId);
	}

	/**
	* Returns all the bulk uploadses where userId = &#63;.
	*
	* @param userId the user ID
	* @return the matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUserId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserId(userId);
	}

	/**
	* Returns a range of all the bulk uploadses where userId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @return the range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUserId(
		long userId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserId(userId, start, end);
	}

	/**
	* Returns an ordered range of all the bulk uploadses where userId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findByUserId(
		long userId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUserId(userId, start, end, orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where userId = &#63;.
	*
	* @param userId the user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByUserId_First(long userId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserId_First(userId, orderByComparator);
	}

	/**
	* Returns the first bulk uploads in the ordered set where userId = &#63;.
	*
	* @param userId the user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByUserId_First(long userId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUserId_First(userId, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where userId = &#63;.
	*
	* @param userId the user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByUserId_Last(long userId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserId_Last(userId, orderByComparator);
	}

	/**
	* Returns the last bulk uploads in the ordered set where userId = &#63;.
	*
	* @param userId the user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByUserId_Last(long userId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUserId_Last(userId, orderByComparator);
	}

	/**
	* Returns the bulk uploadses before and after the current bulk uploads in the ordered set where userId = &#63;.
	*
	* @param id the primary key of the current bulk uploads
	* @param userId the user ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads[] findByUserId_PrevAndNext(
		long id, long userId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUserId_PrevAndNext(id, userId, orderByComparator);
	}

	/**
	* Removes all the bulk uploadses where userId = &#63; from the database.
	*
	* @param userId the user ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUserId(long userId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUserId(userId);
	}

	/**
	* Returns the number of bulk uploadses where userId = &#63;.
	*
	* @param userId the user ID
	* @return the number of matching bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUserId(long userId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUserId(userId);
	}

	/**
	* Caches the bulk uploads in the entity cache if it is enabled.
	*
	* @param bulkUploads the bulk uploads
	*/
	public static void cacheResult(com.ccm.model.BulkUploads bulkUploads) {
		getPersistence().cacheResult(bulkUploads);
	}

	/**
	* Caches the bulk uploadses in the entity cache if it is enabled.
	*
	* @param bulkUploadses the bulk uploadses
	*/
	public static void cacheResult(
		java.util.List<com.ccm.model.BulkUploads> bulkUploadses) {
		getPersistence().cacheResult(bulkUploadses);
	}

	/**
	* Creates a new bulk uploads with the primary key. Does not add the bulk uploads to the database.
	*
	* @param id the primary key for the new bulk uploads
	* @return the new bulk uploads
	*/
	public static com.ccm.model.BulkUploads create(long id) {
		return getPersistence().create(id);
	}

	/**
	* Removes the bulk uploads with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the bulk uploads
	* @return the bulk uploads that was removed
	* @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads remove(long id)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(id);
	}

	public static com.ccm.model.BulkUploads updateImpl(
		com.ccm.model.BulkUploads bulkUploads)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(bulkUploads);
	}

	/**
	* Returns the bulk uploads with the primary key or throws a {@link com.ccm.NoSuchBulkUploadsException} if it could not be found.
	*
	* @param id the primary key of the bulk uploads
	* @return the bulk uploads
	* @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads findByPrimaryKey(long id)
		throws com.ccm.NoSuchBulkUploadsException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(id);
	}

	/**
	* Returns the bulk uploads with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param id the primary key of the bulk uploads
	* @return the bulk uploads, or <code>null</code> if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.ccm.model.BulkUploads fetchByPrimaryKey(long id)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(id);
	}

	/**
	* Returns all the bulk uploadses.
	*
	* @return the bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the bulk uploadses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @return the range of bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the bulk uploadses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.ccm.model.BulkUploads> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the bulk uploadses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of bulk uploadses.
	*
	* @return the number of bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static BulkUploadsPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (BulkUploadsPersistence)PortletBeanLocatorUtil.locate(com.ccm.service.ClpSerializer.getServletContextName(),
					BulkUploadsPersistence.class.getName());

			ReferenceRegistry.registerReference(BulkUploadsUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(BulkUploadsPersistence persistence) {
	}

	private static BulkUploadsPersistence _persistence;
}