/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link CreditCardsLocalService}.
 *
 * @author Shreeya
 * @see CreditCardsLocalService
 * @generated
 */
public class CreditCardsLocalServiceWrapper implements CreditCardsLocalService,
	ServiceWrapper<CreditCardsLocalService> {
	public CreditCardsLocalServiceWrapper(
		CreditCardsLocalService creditCardsLocalService) {
		_creditCardsLocalService = creditCardsLocalService;
	}

	/**
	* Adds the credit cards to the database. Also notifies the appropriate model listeners.
	*
	* @param creditCards the credit cards
	* @return the credit cards that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.CreditCards addCreditCards(
		com.ccm.model.CreditCards creditCards)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.addCreditCards(creditCards);
	}

	/**
	* Creates a new credit cards with the primary key. Does not add the credit cards to the database.
	*
	* @param id the primary key for the new credit cards
	* @return the new credit cards
	*/
	@Override
	public com.ccm.model.CreditCards createCreditCards(long id) {
		return _creditCardsLocalService.createCreditCards(id);
	}

	/**
	* Deletes the credit cards with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the credit cards
	* @return the credit cards that was removed
	* @throws PortalException if a credit cards with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.CreditCards deleteCreditCards(long id)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.deleteCreditCards(id);
	}

	/**
	* Deletes the credit cards from the database. Also notifies the appropriate model listeners.
	*
	* @param creditCards the credit cards
	* @return the credit cards that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.CreditCards deleteCreditCards(
		com.ccm.model.CreditCards creditCards)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.deleteCreditCards(creditCards);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _creditCardsLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.ccm.model.CreditCards fetchCreditCards(long id)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.fetchCreditCards(id);
	}

	/**
	* Returns the credit cards with the primary key.
	*
	* @param id the primary key of the credit cards
	* @return the credit cards
	* @throws PortalException if a credit cards with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.CreditCards getCreditCards(long id)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getCreditCards(id);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the credit cardses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of credit cardses
	* @param end the upper bound of the range of credit cardses (not inclusive)
	* @return the range of credit cardses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.ccm.model.CreditCards> getCreditCardses(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getCreditCardses(start, end);
	}

	/**
	* Returns the number of credit cardses.
	*
	* @return the number of credit cardses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getCreditCardsesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getCreditCardsesCount();
	}

	/**
	* Updates the credit cards in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param creditCards the credit cards
	* @return the credit cards that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.CreditCards updateCreditCards(
		com.ccm.model.CreditCards creditCards)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.updateCreditCards(creditCards);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _creditCardsLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_creditCardsLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _creditCardsLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public java.util.List<com.ccm.model.CreditCards> getCreditCardHolder(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getCreditCardHolder(userId);
	}

	@Override
	public com.ccm.model.CreditCards getCreditCardId(long userId,
		java.lang.String cardNumber)
		throws com.ccm.NoSuchCreditCardsException,
			com.liferay.portal.kernel.exception.SystemException {
		return _creditCardsLocalService.getCreditCardId(userId, cardNumber);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public CreditCardsLocalService getWrappedCreditCardsLocalService() {
		return _creditCardsLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedCreditCardsLocalService(
		CreditCardsLocalService creditCardsLocalService) {
		_creditCardsLocalService = creditCardsLocalService;
	}

	@Override
	public CreditCardsLocalService getWrappedService() {
		return _creditCardsLocalService;
	}

	@Override
	public void setWrappedService(
		CreditCardsLocalService creditCardsLocalService) {
		_creditCardsLocalService = creditCardsLocalService;
	}

	private CreditCardsLocalService _creditCardsLocalService;
}