/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.ccm.service.BulkUploadsLocalServiceUtil;
import com.ccm.service.ClpSerializer;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Shreeya
 */
public class BulkUploadsClp extends BaseModelImpl<BulkUploads>
	implements BulkUploads {
	public BulkUploadsClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return BulkUploads.class;
	}

	@Override
	public String getModelClassName() {
		return BulkUploads.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _id;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _id;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("uploadDate", getUploadDate());
		attributes.put("timeTaken", getTimeTaken());
		attributes.put("totalRecords", getTotalRecords());
		attributes.put("successRecords", getSuccessRecords());
		attributes.put("failedRecords", getFailedRecords());
		attributes.put("fileName", getFileName());
		attributes.put("errorFilePath", getErrorFilePath());
		attributes.put("userId", getUserId());
		attributes.put("creditCardId", getCreditCardId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Date uploadDate = (Date)attributes.get("uploadDate");

		if (uploadDate != null) {
			setUploadDate(uploadDate);
		}

		Double timeTaken = (Double)attributes.get("timeTaken");

		if (timeTaken != null) {
			setTimeTaken(timeTaken);
		}

		Integer totalRecords = (Integer)attributes.get("totalRecords");

		if (totalRecords != null) {
			setTotalRecords(totalRecords);
		}

		Integer successRecords = (Integer)attributes.get("successRecords");

		if (successRecords != null) {
			setSuccessRecords(successRecords);
		}

		Integer failedRecords = (Integer)attributes.get("failedRecords");

		if (failedRecords != null) {
			setFailedRecords(failedRecords);
		}

		String fileName = (String)attributes.get("fileName");

		if (fileName != null) {
			setFileName(fileName);
		}

		String errorFilePath = (String)attributes.get("errorFilePath");

		if (errorFilePath != null) {
			setErrorFilePath(errorFilePath);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Long creditCardId = (Long)attributes.get("creditCardId");

		if (creditCardId != null) {
			setCreditCardId(creditCardId);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_bulkUploadsRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getId() {
		return _id;
	}

	@Override
	public void setId(long id) {
		_id = id;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setId", long.class);

				method.invoke(_bulkUploadsRemoteModel, id);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUploadDate() {
		return _uploadDate;
	}

	@Override
	public void setUploadDate(Date uploadDate) {
		_uploadDate = uploadDate;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setUploadDate", Date.class);

				method.invoke(_bulkUploadsRemoteModel, uploadDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getTimeTaken() {
		return _timeTaken;
	}

	@Override
	public void setTimeTaken(double timeTaken) {
		_timeTaken = timeTaken;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setTimeTaken", double.class);

				method.invoke(_bulkUploadsRemoteModel, timeTaken);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getTotalRecords() {
		return _totalRecords;
	}

	@Override
	public void setTotalRecords(int totalRecords) {
		_totalRecords = totalRecords;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setTotalRecords", int.class);

				method.invoke(_bulkUploadsRemoteModel, totalRecords);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getSuccessRecords() {
		return _successRecords;
	}

	@Override
	public void setSuccessRecords(int successRecords) {
		_successRecords = successRecords;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setSuccessRecords", int.class);

				method.invoke(_bulkUploadsRemoteModel, successRecords);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getFailedRecords() {
		return _failedRecords;
	}

	@Override
	public void setFailedRecords(int failedRecords) {
		_failedRecords = failedRecords;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setFailedRecords", int.class);

				method.invoke(_bulkUploadsRemoteModel, failedRecords);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getFileName() {
		return _fileName;
	}

	@Override
	public void setFileName(String fileName) {
		_fileName = fileName;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setFileName", String.class);

				method.invoke(_bulkUploadsRemoteModel, fileName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getErrorFilePath() {
		return _errorFilePath;
	}

	@Override
	public void setErrorFilePath(String errorFilePath) {
		_errorFilePath = errorFilePath;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setErrorFilePath", String.class);

				method.invoke(_bulkUploadsRemoteModel, errorFilePath);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_bulkUploadsRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public long getCreditCardId() {
		return _creditCardId;
	}

	@Override
	public void setCreditCardId(long creditCardId) {
		_creditCardId = creditCardId;

		if (_bulkUploadsRemoteModel != null) {
			try {
				Class<?> clazz = _bulkUploadsRemoteModel.getClass();

				Method method = clazz.getMethod("setCreditCardId", long.class);

				method.invoke(_bulkUploadsRemoteModel, creditCardId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public void setCustomerName(java.lang.String customerName) {
		try {
			String methodName = "setCustomerName";

			Class<?>[] parameterTypes = new Class<?>[] { java.lang.String.class };

			Object[] parameterValues = new Object[] { customerName };

			invokeOnRemoteModel(methodName, parameterTypes, parameterValues);
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	@Override
	public java.lang.String getCustomerName() {
		try {
			String methodName = "getCustomerName";

			Class<?>[] parameterTypes = new Class<?>[] {  };

			Object[] parameterValues = new Object[] {  };

			java.lang.String returnObj = (java.lang.String)invokeOnRemoteModel(methodName,
					parameterTypes, parameterValues);

			return returnObj;
		}
		catch (Exception e) {
			throw new UnsupportedOperationException(e);
		}
	}

	public BaseModel<?> getBulkUploadsRemoteModel() {
		return _bulkUploadsRemoteModel;
	}

	public void setBulkUploadsRemoteModel(BaseModel<?> bulkUploadsRemoteModel) {
		_bulkUploadsRemoteModel = bulkUploadsRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _bulkUploadsRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_bulkUploadsRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			BulkUploadsLocalServiceUtil.addBulkUploads(this);
		}
		else {
			BulkUploadsLocalServiceUtil.updateBulkUploads(this);
		}
	}

	@Override
	public BulkUploads toEscapedModel() {
		return (BulkUploads)ProxyUtil.newProxyInstance(BulkUploads.class.getClassLoader(),
			new Class[] { BulkUploads.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		BulkUploadsClp clone = new BulkUploadsClp();

		clone.setUuid(getUuid());
		clone.setId(getId());
		clone.setUploadDate(getUploadDate());
		clone.setTimeTaken(getTimeTaken());
		clone.setTotalRecords(getTotalRecords());
		clone.setSuccessRecords(getSuccessRecords());
		clone.setFailedRecords(getFailedRecords());
		clone.setFileName(getFileName());
		clone.setErrorFilePath(getErrorFilePath());
		clone.setUserId(getUserId());
		clone.setCreditCardId(getCreditCardId());

		return clone;
	}

	@Override
	public int compareTo(BulkUploads bulkUploads) {
		long primaryKey = bulkUploads.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BulkUploadsClp)) {
			return false;
		}

		BulkUploadsClp bulkUploads = (BulkUploadsClp)obj;

		long primaryKey = bulkUploads.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", id=");
		sb.append(getId());
		sb.append(", uploadDate=");
		sb.append(getUploadDate());
		sb.append(", timeTaken=");
		sb.append(getTimeTaken());
		sb.append(", totalRecords=");
		sb.append(getTotalRecords());
		sb.append(", successRecords=");
		sb.append(getSuccessRecords());
		sb.append(", failedRecords=");
		sb.append(getFailedRecords());
		sb.append(", fileName=");
		sb.append(getFileName());
		sb.append(", errorFilePath=");
		sb.append(getErrorFilePath());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", creditCardId=");
		sb.append(getCreditCardId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(37);

		sb.append("<model><model-name>");
		sb.append("com.ccm.model.BulkUploads");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>id</column-name><column-value><![CDATA[");
		sb.append(getId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>uploadDate</column-name><column-value><![CDATA[");
		sb.append(getUploadDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>timeTaken</column-name><column-value><![CDATA[");
		sb.append(getTimeTaken());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>totalRecords</column-name><column-value><![CDATA[");
		sb.append(getTotalRecords());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>successRecords</column-name><column-value><![CDATA[");
		sb.append(getSuccessRecords());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>failedRecords</column-name><column-value><![CDATA[");
		sb.append(getFailedRecords());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>fileName</column-name><column-value><![CDATA[");
		sb.append(getFileName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>errorFilePath</column-name><column-value><![CDATA[");
		sb.append(getErrorFilePath());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>creditCardId</column-name><column-value><![CDATA[");
		sb.append(getCreditCardId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _id;
	private Date _uploadDate;
	private double _timeTaken;
	private int _totalRecords;
	private int _successRecords;
	private int _failedRecords;
	private String _fileName;
	private String _errorFilePath;
	private long _userId;
	private String _userUuid;
	private long _creditCardId;
	private BaseModel<?> _bulkUploadsRemoteModel;
	private Class<?> _clpSerializerClass = com.ccm.service.ClpSerializer.class;
}