/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link BulkUploadsLocalService}.
 *
 * @author Shreeya
 * @see BulkUploadsLocalService
 * @generated
 */
public class BulkUploadsLocalServiceWrapper implements BulkUploadsLocalService,
	ServiceWrapper<BulkUploadsLocalService> {
	public BulkUploadsLocalServiceWrapper(
		BulkUploadsLocalService bulkUploadsLocalService) {
		_bulkUploadsLocalService = bulkUploadsLocalService;
	}

	/**
	* Adds the bulk uploads to the database. Also notifies the appropriate model listeners.
	*
	* @param bulkUploads the bulk uploads
	* @return the bulk uploads that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.BulkUploads addBulkUploads(
		com.ccm.model.BulkUploads bulkUploads)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.addBulkUploads(bulkUploads);
	}

	/**
	* Creates a new bulk uploads with the primary key. Does not add the bulk uploads to the database.
	*
	* @param id the primary key for the new bulk uploads
	* @return the new bulk uploads
	*/
	@Override
	public com.ccm.model.BulkUploads createBulkUploads(long id) {
		return _bulkUploadsLocalService.createBulkUploads(id);
	}

	/**
	* Deletes the bulk uploads with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the bulk uploads
	* @return the bulk uploads that was removed
	* @throws PortalException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.BulkUploads deleteBulkUploads(long id)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.deleteBulkUploads(id);
	}

	/**
	* Deletes the bulk uploads from the database. Also notifies the appropriate model listeners.
	*
	* @param bulkUploads the bulk uploads
	* @return the bulk uploads that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.BulkUploads deleteBulkUploads(
		com.ccm.model.BulkUploads bulkUploads)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.deleteBulkUploads(bulkUploads);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _bulkUploadsLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.ccm.model.BulkUploads fetchBulkUploads(long id)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.fetchBulkUploads(id);
	}

	/**
	* Returns the bulk uploads with the primary key.
	*
	* @param id the primary key of the bulk uploads
	* @return the bulk uploads
	* @throws PortalException if a bulk uploads with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.BulkUploads getBulkUploads(long id)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.getBulkUploads(id);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the bulk uploadses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of bulk uploadses
	* @param end the upper bound of the range of bulk uploadses (not inclusive)
	* @return the range of bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.ccm.model.BulkUploads> getBulkUploadses(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.getBulkUploadses(start, end);
	}

	/**
	* Returns the number of bulk uploadses.
	*
	* @return the number of bulk uploadses
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getBulkUploadsesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.getBulkUploadsesCount();
	}

	/**
	* Updates the bulk uploads in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param bulkUploads the bulk uploads
	* @return the bulk uploads that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.ccm.model.BulkUploads updateBulkUploads(
		com.ccm.model.BulkUploads bulkUploads)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploadsLocalService.updateBulkUploads(bulkUploads);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _bulkUploadsLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_bulkUploadsLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _bulkUploadsLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public BulkUploadsLocalService getWrappedBulkUploadsLocalService() {
		return _bulkUploadsLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedBulkUploadsLocalService(
		BulkUploadsLocalService bulkUploadsLocalService) {
		_bulkUploadsLocalService = bulkUploadsLocalService;
	}

	@Override
	public BulkUploadsLocalService getWrappedService() {
		return _bulkUploadsLocalService;
	}

	@Override
	public void setWrappedService(
		BulkUploadsLocalService bulkUploadsLocalService) {
		_bulkUploadsLocalService = bulkUploadsLocalService;
	}

	private BulkUploadsLocalService _bulkUploadsLocalService;
}