/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link BulkUploads}.
 * </p>
 *
 * @author Shreeya
 * @see BulkUploads
 * @generated
 */
public class BulkUploadsWrapper implements BulkUploads,
	ModelWrapper<BulkUploads> {
	public BulkUploadsWrapper(BulkUploads bulkUploads) {
		_bulkUploads = bulkUploads;
	}

	@Override
	public Class<?> getModelClass() {
		return BulkUploads.class;
	}

	@Override
	public String getModelClassName() {
		return BulkUploads.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("uploadDate", getUploadDate());
		attributes.put("timeTaken", getTimeTaken());
		attributes.put("totalRecords", getTotalRecords());
		attributes.put("successRecords", getSuccessRecords());
		attributes.put("failedRecords", getFailedRecords());
		attributes.put("fileName", getFileName());
		attributes.put("errorFilePath", getErrorFilePath());
		attributes.put("userId", getUserId());
		attributes.put("creditCardId", getCreditCardId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		Date uploadDate = (Date)attributes.get("uploadDate");

		if (uploadDate != null) {
			setUploadDate(uploadDate);
		}

		Double timeTaken = (Double)attributes.get("timeTaken");

		if (timeTaken != null) {
			setTimeTaken(timeTaken);
		}

		Integer totalRecords = (Integer)attributes.get("totalRecords");

		if (totalRecords != null) {
			setTotalRecords(totalRecords);
		}

		Integer successRecords = (Integer)attributes.get("successRecords");

		if (successRecords != null) {
			setSuccessRecords(successRecords);
		}

		Integer failedRecords = (Integer)attributes.get("failedRecords");

		if (failedRecords != null) {
			setFailedRecords(failedRecords);
		}

		String fileName = (String)attributes.get("fileName");

		if (fileName != null) {
			setFileName(fileName);
		}

		String errorFilePath = (String)attributes.get("errorFilePath");

		if (errorFilePath != null) {
			setErrorFilePath(errorFilePath);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Long creditCardId = (Long)attributes.get("creditCardId");

		if (creditCardId != null) {
			setCreditCardId(creditCardId);
		}
	}

	/**
	* Returns the primary key of this bulk uploads.
	*
	* @return the primary key of this bulk uploads
	*/
	@Override
	public long getPrimaryKey() {
		return _bulkUploads.getPrimaryKey();
	}

	/**
	* Sets the primary key of this bulk uploads.
	*
	* @param primaryKey the primary key of this bulk uploads
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_bulkUploads.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this bulk uploads.
	*
	* @return the uuid of this bulk uploads
	*/
	@Override
	public java.lang.String getUuid() {
		return _bulkUploads.getUuid();
	}

	/**
	* Sets the uuid of this bulk uploads.
	*
	* @param uuid the uuid of this bulk uploads
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_bulkUploads.setUuid(uuid);
	}

	/**
	* Returns the ID of this bulk uploads.
	*
	* @return the ID of this bulk uploads
	*/
	@Override
	public long getId() {
		return _bulkUploads.getId();
	}

	/**
	* Sets the ID of this bulk uploads.
	*
	* @param id the ID of this bulk uploads
	*/
	@Override
	public void setId(long id) {
		_bulkUploads.setId(id);
	}

	/**
	* Returns the upload date of this bulk uploads.
	*
	* @return the upload date of this bulk uploads
	*/
	@Override
	public java.util.Date getUploadDate() {
		return _bulkUploads.getUploadDate();
	}

	/**
	* Sets the upload date of this bulk uploads.
	*
	* @param uploadDate the upload date of this bulk uploads
	*/
	@Override
	public void setUploadDate(java.util.Date uploadDate) {
		_bulkUploads.setUploadDate(uploadDate);
	}

	/**
	* Returns the time taken of this bulk uploads.
	*
	* @return the time taken of this bulk uploads
	*/
	@Override
	public double getTimeTaken() {
		return _bulkUploads.getTimeTaken();
	}

	/**
	* Sets the time taken of this bulk uploads.
	*
	* @param timeTaken the time taken of this bulk uploads
	*/
	@Override
	public void setTimeTaken(double timeTaken) {
		_bulkUploads.setTimeTaken(timeTaken);
	}

	/**
	* Returns the total records of this bulk uploads.
	*
	* @return the total records of this bulk uploads
	*/
	@Override
	public int getTotalRecords() {
		return _bulkUploads.getTotalRecords();
	}

	/**
	* Sets the total records of this bulk uploads.
	*
	* @param totalRecords the total records of this bulk uploads
	*/
	@Override
	public void setTotalRecords(int totalRecords) {
		_bulkUploads.setTotalRecords(totalRecords);
	}

	/**
	* Returns the success records of this bulk uploads.
	*
	* @return the success records of this bulk uploads
	*/
	@Override
	public int getSuccessRecords() {
		return _bulkUploads.getSuccessRecords();
	}

	/**
	* Sets the success records of this bulk uploads.
	*
	* @param successRecords the success records of this bulk uploads
	*/
	@Override
	public void setSuccessRecords(int successRecords) {
		_bulkUploads.setSuccessRecords(successRecords);
	}

	/**
	* Returns the failed records of this bulk uploads.
	*
	* @return the failed records of this bulk uploads
	*/
	@Override
	public int getFailedRecords() {
		return _bulkUploads.getFailedRecords();
	}

	/**
	* Sets the failed records of this bulk uploads.
	*
	* @param failedRecords the failed records of this bulk uploads
	*/
	@Override
	public void setFailedRecords(int failedRecords) {
		_bulkUploads.setFailedRecords(failedRecords);
	}

	/**
	* Returns the file name of this bulk uploads.
	*
	* @return the file name of this bulk uploads
	*/
	@Override
	public java.lang.String getFileName() {
		return _bulkUploads.getFileName();
	}

	/**
	* Sets the file name of this bulk uploads.
	*
	* @param fileName the file name of this bulk uploads
	*/
	@Override
	public void setFileName(java.lang.String fileName) {
		_bulkUploads.setFileName(fileName);
	}

	/**
	* Returns the error file path of this bulk uploads.
	*
	* @return the error file path of this bulk uploads
	*/
	@Override
	public java.lang.String getErrorFilePath() {
		return _bulkUploads.getErrorFilePath();
	}

	/**
	* Sets the error file path of this bulk uploads.
	*
	* @param errorFilePath the error file path of this bulk uploads
	*/
	@Override
	public void setErrorFilePath(java.lang.String errorFilePath) {
		_bulkUploads.setErrorFilePath(errorFilePath);
	}

	/**
	* Returns the user ID of this bulk uploads.
	*
	* @return the user ID of this bulk uploads
	*/
	@Override
	public long getUserId() {
		return _bulkUploads.getUserId();
	}

	/**
	* Sets the user ID of this bulk uploads.
	*
	* @param userId the user ID of this bulk uploads
	*/
	@Override
	public void setUserId(long userId) {
		_bulkUploads.setUserId(userId);
	}

	/**
	* Returns the user uuid of this bulk uploads.
	*
	* @return the user uuid of this bulk uploads
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _bulkUploads.getUserUuid();
	}

	/**
	* Sets the user uuid of this bulk uploads.
	*
	* @param userUuid the user uuid of this bulk uploads
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_bulkUploads.setUserUuid(userUuid);
	}

	/**
	* Returns the credit card ID of this bulk uploads.
	*
	* @return the credit card ID of this bulk uploads
	*/
	@Override
	public long getCreditCardId() {
		return _bulkUploads.getCreditCardId();
	}

	/**
	* Sets the credit card ID of this bulk uploads.
	*
	* @param creditCardId the credit card ID of this bulk uploads
	*/
	@Override
	public void setCreditCardId(long creditCardId) {
		_bulkUploads.setCreditCardId(creditCardId);
	}

	@Override
	public boolean isNew() {
		return _bulkUploads.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_bulkUploads.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _bulkUploads.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_bulkUploads.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _bulkUploads.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _bulkUploads.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_bulkUploads.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _bulkUploads.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_bulkUploads.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_bulkUploads.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_bulkUploads.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new BulkUploadsWrapper((BulkUploads)_bulkUploads.clone());
	}

	@Override
	public int compareTo(com.ccm.model.BulkUploads bulkUploads) {
		return _bulkUploads.compareTo(bulkUploads);
	}

	@Override
	public int hashCode() {
		return _bulkUploads.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.ccm.model.BulkUploads> toCacheModel() {
		return _bulkUploads.toCacheModel();
	}

	@Override
	public com.ccm.model.BulkUploads toEscapedModel() {
		return new BulkUploadsWrapper(_bulkUploads.toEscapedModel());
	}

	@Override
	public com.ccm.model.BulkUploads toUnescapedModel() {
		return new BulkUploadsWrapper(_bulkUploads.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _bulkUploads.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _bulkUploads.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_bulkUploads.persist();
	}

	@Override
	public java.lang.String getCustomerName() {
		return _bulkUploads.getCustomerName();
	}

	@Override
	public void setCustomerName(java.lang.String customerName) {
		_bulkUploads.setCustomerName(customerName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BulkUploadsWrapper)) {
			return false;
		}

		BulkUploadsWrapper bulkUploadsWrapper = (BulkUploadsWrapper)obj;

		if (Validator.equals(_bulkUploads, bulkUploadsWrapper._bulkUploads)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public BulkUploads getWrappedBulkUploads() {
		return _bulkUploads;
	}

	@Override
	public BulkUploads getWrappedModel() {
		return _bulkUploads;
	}

	@Override
	public void resetOriginalValues() {
		_bulkUploads.resetOriginalValues();
	}

	private BulkUploads _bulkUploads;
}