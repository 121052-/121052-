package com.ccm.DTO;


public class TransactionDetails {
	private String transactionDate;
	private String description;
	private double amount;
	public double getAmount() {
		return amount;
	}
	public void setAmount(double d) {
		this.amount = d;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate2) {
		this.transactionDate = transactionDate2;
	}
	
}
