create index IX_BB05EE8C on CCM_BulkUploads (creditCardId);
create index IX_A8A842E on CCM_BulkUploads (userId);
create index IX_5687AF40 on CCM_BulkUploads (uuid_);

create index IX_675055EB on CCM_CreditCards (cardNumber);
create index IX_4C934E78 on CCM_CreditCards (userId);
create index IX_EA750925 on CCM_CreditCards (userId, cardNumber);
create index IX_927773B6 on CCM_CreditCards (uuid_);

create index IX_9AEAE11E on CCM_Customer (uuid_);

create index IX_40FE45B on CCM_Statement (creditCardId);
create index IX_14661451 on CCM_Statement (uuid_);

create index IX_1375965 on CCM_Transactions (creditCardId);
create index IX_17745C7 on CCM_Transactions (userId);
create index IX_E29FD687 on CCM_Transactions (uuid_);