create table CCM_BulkUploads (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key IDENTITY,
	uploadDate DATE null,
	timeTaken DOUBLE,
	totalRecords INTEGER,
	successRecords INTEGER,
	failedRecords INTEGER,
	fileName VARCHAR(75) null,
	errorFilePath VARCHAR(75) null,
	userId LONG,
	creditCardId LONG
);

create table CCM_CreditCards (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key IDENTITY,
	cardNumber VARCHAR(75) null,
	validFromDate DATE null,
	validToDate DATE null,
	cvv LONG,
	nameOnCard VARCHAR(75) null,
	statementDate VARCHAR(75) null,
	userId LONG,
	creditLimit DOUBLE,
	availableCreditLimit DOUBLE,
	royalty_points INTEGER
);

create table CCM_Customer (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key IDENTITY
);

create table CCM_Statement (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key IDENTITY,
	creditCardId LONG,
	statementDate DATE null,
	fromDate DATE null,
	toDate DATE null,
	amountDue DOUBLE,
	statementFilePath VARCHAR(250) null
);

create table CCM_Transactions (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key IDENTITY,
	creditCardId LONG,
	amount DOUBLE,
	transactionDate DATE null,
	balance DOUBLE,
	description VARCHAR(75) null,
	userId LONG
);