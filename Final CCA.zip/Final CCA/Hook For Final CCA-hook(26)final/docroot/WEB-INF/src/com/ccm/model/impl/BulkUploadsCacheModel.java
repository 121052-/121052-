/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model.impl;

import com.ccm.model.BulkUploads;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing BulkUploads in entity cache.
 *
 * @author Shreeya
 * @see BulkUploads
 * @generated
 */
public class BulkUploadsCacheModel implements CacheModel<BulkUploads>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", id=");
		sb.append(id);
		sb.append(", uploadDate=");
		sb.append(uploadDate);
		sb.append(", timeTaken=");
		sb.append(timeTaken);
		sb.append(", totalRecords=");
		sb.append(totalRecords);
		sb.append(", successRecords=");
		sb.append(successRecords);
		sb.append(", failedRecords=");
		sb.append(failedRecords);
		sb.append(", fileName=");
		sb.append(fileName);
		sb.append(", errorFilePath=");
		sb.append(errorFilePath);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", creditCardId=");
		sb.append(creditCardId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public BulkUploads toEntityModel() {
		BulkUploadsImpl bulkUploadsImpl = new BulkUploadsImpl();

		if (uuid == null) {
			bulkUploadsImpl.setUuid(StringPool.BLANK);
		}
		else {
			bulkUploadsImpl.setUuid(uuid);
		}

		bulkUploadsImpl.setId(id);

		if (uploadDate == Long.MIN_VALUE) {
			bulkUploadsImpl.setUploadDate(null);
		}
		else {
			bulkUploadsImpl.setUploadDate(new Date(uploadDate));
		}

		bulkUploadsImpl.setTimeTaken(timeTaken);
		bulkUploadsImpl.setTotalRecords(totalRecords);
		bulkUploadsImpl.setSuccessRecords(successRecords);
		bulkUploadsImpl.setFailedRecords(failedRecords);

		if (fileName == null) {
			bulkUploadsImpl.setFileName(StringPool.BLANK);
		}
		else {
			bulkUploadsImpl.setFileName(fileName);
		}

		if (errorFilePath == null) {
			bulkUploadsImpl.setErrorFilePath(StringPool.BLANK);
		}
		else {
			bulkUploadsImpl.setErrorFilePath(errorFilePath);
		}

		bulkUploadsImpl.setUserId(userId);
		bulkUploadsImpl.setCreditCardId(creditCardId);

		bulkUploadsImpl.resetOriginalValues();

		return bulkUploadsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		id = objectInput.readLong();
		uploadDate = objectInput.readLong();
		timeTaken = objectInput.readDouble();
		totalRecords = objectInput.readInt();
		successRecords = objectInput.readInt();
		failedRecords = objectInput.readInt();
		fileName = objectInput.readUTF();
		errorFilePath = objectInput.readUTF();
		userId = objectInput.readLong();
		creditCardId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(id);
		objectOutput.writeLong(uploadDate);
		objectOutput.writeDouble(timeTaken);
		objectOutput.writeInt(totalRecords);
		objectOutput.writeInt(successRecords);
		objectOutput.writeInt(failedRecords);

		if (fileName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(fileName);
		}

		if (errorFilePath == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(errorFilePath);
		}

		objectOutput.writeLong(userId);
		objectOutput.writeLong(creditCardId);
	}

	public String uuid;
	public long id;
	public long uploadDate;
	public double timeTaken;
	public int totalRecords;
	public int successRecords;
	public int failedRecords;
	public String fileName;
	public String errorFilePath;
	public long userId;
	public long creditCardId;
}