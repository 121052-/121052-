/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ccm.DTO.TransactionDetails;
import com.ccm.amazons3.AmazonRepositoryService;

import org.apache.commons.io.IOUtils;

import com.ccm.model.CreditCards;
import com.ccm.model.Statement;
import com.ccm.model.Transactions;
import com.ccm.model.impl.TransactionsImpl;
import com.ccm.service.CreditCardsLocalServiceUtil;
import com.ccm.service.StatementLocalServiceUtil;
import com.ccm.service.base.TransactionsLocalServiceBaseImpl;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;

/**
 * The implementation of the transactions local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are
 * added, rerun ServiceBuilder to copy their definitions into the
 * {@link com.ccm.service.TransactionsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security
 * checks based on the propagated JAAS credentials because this service can only
 * be accessed from within the same VM.
 * </p>
 *
 * @author Shreeya
 * @see com.ccm.service.base.TransactionsLocalServiceBaseImpl
 * @see com.ccm.service.TransactionsLocalServiceUtil
 */
public class TransactionsLocalServiceImpl extends TransactionsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link
	 * com.ccm.service.TransactionsLocalServiceUtil} to access the transactions
	 * local service.
	 */
	private AmazonRepositoryService amazonRepositoryService = new AmazonRepositoryService();

	public List<Transactions> getUserTransactions(long userId) throws SystemException{
		return transactionsPersistence.findByUserId(userId);
	}
	
	@SuppressWarnings("unchecked")
	public List<Transactions> getAllTransactionBetweenDate(Date fromDate, Date toDate) {
		List<Transactions> transactionList = new ArrayList<Transactions>();
		DynamicQuery query = null;
		query = DynamicQueryFactoryUtil.forClass(TransactionsImpl.class);
		query.add(PropertyFactoryUtil.forName("transactionDate").between(fromDate, toDate));

		try {
			transactionList = transactionsLocalService.dynamicQuery(query);
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Map<Long, List<Transactions>> transactionMap = new HashMap<Long, List<Transactions>>();
		for (Transactions transactions : transactionList) {
			List<Transactions> tempList = transactionMap.get(transactions.getCreditCardId());
			if (Validator.isNull(tempList)) {
				tempList = new ArrayList<Transactions>();
			}
			tempList.add(transactions);
			transactionMap.put(transactions.getCreditCardId(), tempList);
		}
		for (Long id : transactionMap.keySet()) {
			List<Transactions> transactions = transactionMap.get(id);

			try {
				double amount = 0;
				Statement statement = StatementLocalServiceUtil.createStatement(CounterLocalServiceUtil.increment());
				List<TransactionDetails> transactionReportDtoList = new ArrayList<TransactionDetails>();
				transactionReportDtoList.add(0, new TransactionDetails());
				long userId = 0;
				for (Transactions transactions3 : transactions) {
					TransactionDetails transactionReportDto = new TransactionDetails();
					transactionReportDto.setAmount(transactions3.getAmount());
					transactionReportDto.setDescription(transactions3.getDescription());
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					String transactionDate = dateFormat.format(transactions3.getTransactionDate().getTime());
					transactionReportDto.setTransactionDate(transactionDate);
					transactionReportDtoList.add(transactionReportDto);
					amount = amount + transactions3.getAmount();
					userId = transactions3.getUserId();
				}
				String url = generatePDF(id, transactions, userId, statement, amount, transactionReportDtoList);
				
				statement.setCreditCardId(id);
				statement.setStatementDate(new Date());
				statement.setFromDate(fromDate);
				statement.setToDate(toDate);
				statement.setAmountDue(amount);
				statement.setStatementFilePath(url);
				StatementLocalServiceUtil.addStatement(statement);

			} catch (SystemException e) {
				e.printStackTrace();
				System.out.println(e);
			}
		}
		return transactionList;
	}

	private String generatePDF(Long id, List<Transactions> transactions, long userId, Statement statement,
			Double amount, List<TransactionDetails> transactionReportDtoList) {

		Calendar calendarStart = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		calendarStart.add(Calendar.DATE, 15);
		Date date = calendarStart.getTime();
		String filePath = null;
		String address = null;
		String dueDateString = dateFormat.format(date);
		try {
			User user = UserLocalServiceUtil.getUser(userId);
			CreditCards cards = CreditCardsLocalServiceUtil.getCreditCards(id);
			for(Address user1: user.getAddresses()){
				address = user1.getStreet1() + " " + user1.getCity();
			}

			Map<String, Object> reportParameters = new HashMap<String, Object>();
			reportParameters.put(CCMConstant.REPORT_PARAM_CARDNUMBER, String.valueOf(cards.getId()));
			reportParameters.put(CCMConstant.REPORT_PARAM_NAME, cards.getNameOnCard());

			reportParameters.put(CCMConstant.REPORT_PARAM_PAYMENTDATE, dueDateString);
			reportParameters.put(CCMConstant.REPORT_PARAM_PAYMENTDUE, String.valueOf(amount));
			reportParameters.put(CCMConstant.REPORT_PARAM_CREDITAVAILABLE,
					String.valueOf(cards.getAvailableCreditLimit()));
			if (Validator.isNull(user.getAddresses()) || user.getAddresses().equals("")) {
				reportParameters.put(CCMConstant.REPORT_PARAM_ADDRESS, "Adress not avalaible");
			} else {
				reportParameters.put(CCMConstant.REPORT_PARAM_ADDRESS, address);
			}
			reportParameters.put(CCMConstant.REPORT_PARAM_STATEMENTDATE, String.valueOf(statement.getStatementDate()));

			JRDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(transactionReportDtoList);
			String sourceFileName = CCMConstant.REPORT_RESOURCE_FOLDER_PATH + CCMConstant.STATEMENT_JASPER_FILE_NAME;

			JasperPrint jasperPrint;

			jasperPrint = JasperFillManager.fillReport(getClass().getResourceAsStream(sourceFileName), reportParameters,
					beanCollectionDataSource);
			ByteArrayOutputStream os = new ByteArrayOutputStream();
			JRPdfExporter exporterPDF = new JRPdfExporter();
			exporterPDF.setParameter(JRXlsExporterParameter.JASPER_PRINT, jasperPrint);
			exporterPDF.setParameter(JRXlsExporterParameter.OUTPUT_STREAM, os);
			exporterPDF.exportReport();
			InputStream is = new ByteArrayInputStream(os.toByteArray());
			java.io.File tempMonthStatementFile = null;
			OutputStream output = null;

			tempMonthStatementFile = java.io.File.createTempFile(CCMConstant.STATEMENT_KEY,
					CCMConstant.PDF_FILE_EXTENTION);
			output = new FileOutputStream(tempMonthStatementFile);
			IOUtils.copy(is, output);

			String fileUploadPath = CCMConstant.AMAZON_S3_FILE_UPLOAD_PATH.replace("[userId]", String.valueOf(userId));
			String fileUploadStatementPath = CCMConstant.AMAZON_S3_FILE_UPLOAD_STATEMENT_PATH
					.replace("[creditCardNumber]", cards.getCardNumber());
			filePath = fileUploadPath + fileUploadStatementPath;
			filePath = filePath + "/" + CCMConstant.STATEMENT_KEY + new Date().getTime()
					+ CCMConstant.PDF_FILE_EXTENTION;
			// Upload file to amazon
			amazonRepositoryService.setKey();
			amazonRepositoryService.uploadFileToAmazonS3Server(tempMonthStatementFile, filePath);

			is.close();
			output.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (JRException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}
		return filePath;
	}
}