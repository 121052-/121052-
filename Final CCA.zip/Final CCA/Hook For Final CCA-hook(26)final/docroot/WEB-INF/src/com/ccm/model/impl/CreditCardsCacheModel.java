/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model.impl;

import com.ccm.model.CreditCards;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing CreditCards in entity cache.
 *
 * @author Shreeya
 * @see CreditCards
 * @generated
 */
public class CreditCardsCacheModel implements CacheModel<CreditCards>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(25);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", id=");
		sb.append(id);
		sb.append(", cardNumber=");
		sb.append(cardNumber);
		sb.append(", validFromDate=");
		sb.append(validFromDate);
		sb.append(", validToDate=");
		sb.append(validToDate);
		sb.append(", cvv=");
		sb.append(cvv);
		sb.append(", nameOnCard=");
		sb.append(nameOnCard);
		sb.append(", statementDate=");
		sb.append(statementDate);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", creditLimit=");
		sb.append(creditLimit);
		sb.append(", availableCreditLimit=");
		sb.append(availableCreditLimit);
		sb.append(", royalty_points=");
		sb.append(royalty_points);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public CreditCards toEntityModel() {
		CreditCardsImpl creditCardsImpl = new CreditCardsImpl();

		if (uuid == null) {
			creditCardsImpl.setUuid(StringPool.BLANK);
		}
		else {
			creditCardsImpl.setUuid(uuid);
		}

		creditCardsImpl.setId(id);

		if (cardNumber == null) {
			creditCardsImpl.setCardNumber(StringPool.BLANK);
		}
		else {
			creditCardsImpl.setCardNumber(cardNumber);
		}

		if (validFromDate == Long.MIN_VALUE) {
			creditCardsImpl.setValidFromDate(null);
		}
		else {
			creditCardsImpl.setValidFromDate(new Date(validFromDate));
		}

		if (validToDate == Long.MIN_VALUE) {
			creditCardsImpl.setValidToDate(null);
		}
		else {
			creditCardsImpl.setValidToDate(new Date(validToDate));
		}

		creditCardsImpl.setCvv(cvv);

		if (nameOnCard == null) {
			creditCardsImpl.setNameOnCard(StringPool.BLANK);
		}
		else {
			creditCardsImpl.setNameOnCard(nameOnCard);
		}

		if (statementDate == null) {
			creditCardsImpl.setStatementDate(StringPool.BLANK);
		}
		else {
			creditCardsImpl.setStatementDate(statementDate);
		}

		creditCardsImpl.setUserId(userId);
		creditCardsImpl.setCreditLimit(creditLimit);
		creditCardsImpl.setAvailableCreditLimit(availableCreditLimit);
		creditCardsImpl.setRoyalty_points(royalty_points);

		creditCardsImpl.resetOriginalValues();

		return creditCardsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		id = objectInput.readLong();
		cardNumber = objectInput.readUTF();
		validFromDate = objectInput.readLong();
		validToDate = objectInput.readLong();
		cvv = objectInput.readLong();
		nameOnCard = objectInput.readUTF();
		statementDate = objectInput.readUTF();
		userId = objectInput.readLong();
		creditLimit = objectInput.readDouble();
		availableCreditLimit = objectInput.readDouble();
		royalty_points = objectInput.readInt();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(id);

		if (cardNumber == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(cardNumber);
		}

		objectOutput.writeLong(validFromDate);
		objectOutput.writeLong(validToDate);
		objectOutput.writeLong(cvv);

		if (nameOnCard == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(nameOnCard);
		}

		if (statementDate == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statementDate);
		}

		objectOutput.writeLong(userId);
		objectOutput.writeDouble(creditLimit);
		objectOutput.writeDouble(availableCreditLimit);
		objectOutput.writeInt(royalty_points);
	}

	public String uuid;
	public long id;
	public String cardNumber;
	public long validFromDate;
	public long validToDate;
	public long cvv;
	public String nameOnCard;
	public String statementDate;
	public long userId;
	public double creditLimit;
	public double availableCreditLimit;
	public int royalty_points;
}