/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.persistence;

import com.ccm.NoSuchBulkUploadsException;

import com.ccm.model.BulkUploads;
import com.ccm.model.impl.BulkUploadsImpl;
import com.ccm.model.impl.BulkUploadsModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the bulk uploads service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Shreeya
 * @see BulkUploadsPersistence
 * @see BulkUploadsUtil
 * @generated
 */
public class BulkUploadsPersistenceImpl extends BasePersistenceImpl<BulkUploads>
	implements BulkUploadsPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link BulkUploadsUtil} to access the bulk uploads persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = BulkUploadsImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			BulkUploadsModelImpl.UUID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the bulk uploadses where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bulk uploadses where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @return the range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bulk uploadses where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<BulkUploads> list = (List<BulkUploads>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BulkUploads bulkUploads : list) {
				if (!Validator.equals(uuid, bulkUploads.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BulkUploads>(list);
				}
				else {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bulk uploads in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByUuid_First(uuid, orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the first bulk uploads in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<BulkUploads> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bulk uploads in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByUuid_Last(uuid, orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the last bulk uploads in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<BulkUploads> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bulk uploadses before and after the current bulk uploads in the ordered set where uuid = &#63;.
	 *
	 * @param id the primary key of the current bulk uploads
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads[] findByUuid_PrevAndNext(long id, String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			BulkUploads[] array = new BulkUploadsImpl[3];

			array[0] = getByUuid_PrevAndNext(session, bulkUploads, uuid,
					orderByComparator, true);

			array[1] = bulkUploads;

			array[2] = getByUuid_PrevAndNext(session, bulkUploads, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BulkUploads getByUuid_PrevAndNext(Session session,
		BulkUploads bulkUploads, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bulkUploads);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BulkUploads> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bulk uploadses where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (BulkUploads bulkUploads : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(bulkUploads);
		}
	}

	/**
	 * Returns the number of bulk uploadses where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BULKUPLOADS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "bulkUploads.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "bulkUploads.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(bulkUploads.uuid IS NULL OR bulkUploads.uuid = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_CREDITCARDID =
		new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByCreditCardId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CREDITCARDID =
		new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByCreditCardId",
			new String[] { Long.class.getName() },
			BulkUploadsModelImpl.CREDITCARDID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_CREDITCARDID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByCreditCardId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the bulk uploadses where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @return the matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByCreditCardId(long creditCardId)
		throws SystemException {
		return findByCreditCardId(creditCardId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bulk uploadses where creditCardId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param creditCardId the credit card ID
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @return the range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByCreditCardId(long creditCardId, int start,
		int end) throws SystemException {
		return findByCreditCardId(creditCardId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bulk uploadses where creditCardId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param creditCardId the credit card ID
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByCreditCardId(long creditCardId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CREDITCARDID;
			finderArgs = new Object[] { creditCardId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_CREDITCARDID;
			finderArgs = new Object[] {
					creditCardId,
					
					start, end, orderByComparator
				};
		}

		List<BulkUploads> list = (List<BulkUploads>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BulkUploads bulkUploads : list) {
				if ((creditCardId != bulkUploads.getCreditCardId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

			query.append(_FINDER_COLUMN_CREDITCARDID_CREDITCARDID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(creditCardId);

				if (!pagination) {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BulkUploads>(list);
				}
				else {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bulk uploads in the ordered set where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByCreditCardId_First(long creditCardId,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByCreditCardId_First(creditCardId,
				orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("creditCardId=");
		msg.append(creditCardId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the first bulk uploads in the ordered set where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByCreditCardId_First(long creditCardId,
		OrderByComparator orderByComparator) throws SystemException {
		List<BulkUploads> list = findByCreditCardId(creditCardId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bulk uploads in the ordered set where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByCreditCardId_Last(long creditCardId,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByCreditCardId_Last(creditCardId,
				orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("creditCardId=");
		msg.append(creditCardId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the last bulk uploads in the ordered set where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByCreditCardId_Last(long creditCardId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByCreditCardId(creditCardId);

		if (count == 0) {
			return null;
		}

		List<BulkUploads> list = findByCreditCardId(creditCardId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bulk uploadses before and after the current bulk uploads in the ordered set where creditCardId = &#63;.
	 *
	 * @param id the primary key of the current bulk uploads
	 * @param creditCardId the credit card ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads[] findByCreditCardId_PrevAndNext(long id,
		long creditCardId, OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			BulkUploads[] array = new BulkUploadsImpl[3];

			array[0] = getByCreditCardId_PrevAndNext(session, bulkUploads,
					creditCardId, orderByComparator, true);

			array[1] = bulkUploads;

			array[2] = getByCreditCardId_PrevAndNext(session, bulkUploads,
					creditCardId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BulkUploads getByCreditCardId_PrevAndNext(Session session,
		BulkUploads bulkUploads, long creditCardId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

		query.append(_FINDER_COLUMN_CREDITCARDID_CREDITCARDID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(creditCardId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bulkUploads);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BulkUploads> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bulk uploadses where creditCardId = &#63; from the database.
	 *
	 * @param creditCardId the credit card ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByCreditCardId(long creditCardId)
		throws SystemException {
		for (BulkUploads bulkUploads : findByCreditCardId(creditCardId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(bulkUploads);
		}
	}

	/**
	 * Returns the number of bulk uploadses where creditCardId = &#63;.
	 *
	 * @param creditCardId the credit card ID
	 * @return the number of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByCreditCardId(long creditCardId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_CREDITCARDID;

		Object[] finderArgs = new Object[] { creditCardId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BULKUPLOADS_WHERE);

			query.append(_FINDER_COLUMN_CREDITCARDID_CREDITCARDID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(creditCardId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_CREDITCARDID_CREDITCARDID_2 = "bulkUploads.creditCardId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUserId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID =
		new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, BulkUploadsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUserId",
			new String[] { Long.class.getName() },
			BulkUploadsModelImpl.USERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_USERID = new FinderPath(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUserId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the bulk uploadses where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @return the matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUserId(long userId)
		throws SystemException {
		return findByUserId(userId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bulk uploadses where userId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @return the range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUserId(long userId, int start, int end)
		throws SystemException {
		return findByUserId(userId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the bulk uploadses where userId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findByUserId(long userId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID;
			finderArgs = new Object[] { userId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID;
			finderArgs = new Object[] { userId, start, end, orderByComparator };
		}

		List<BulkUploads> list = (List<BulkUploads>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (BulkUploads bulkUploads : list) {
				if ((userId != bulkUploads.getUserId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

			query.append(_FINDER_COLUMN_USERID_USERID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				if (!pagination) {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BulkUploads>(list);
				}
				else {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first bulk uploads in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByUserId_First(long userId,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByUserId_First(userId, orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the first bulk uploads in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByUserId_First(long userId,
		OrderByComparator orderByComparator) throws SystemException {
		List<BulkUploads> list = findByUserId(userId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last bulk uploads in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByUserId_Last(long userId,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByUserId_Last(userId, orderByComparator);

		if (bulkUploads != null) {
			return bulkUploads;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchBulkUploadsException(msg.toString());
	}

	/**
	 * Returns the last bulk uploads in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching bulk uploads, or <code>null</code> if a matching bulk uploads could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByUserId_Last(long userId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUserId(userId);

		if (count == 0) {
			return null;
		}

		List<BulkUploads> list = findByUserId(userId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the bulk uploadses before and after the current bulk uploads in the ordered set where userId = &#63;.
	 *
	 * @param id the primary key of the current bulk uploads
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads[] findByUserId_PrevAndNext(long id, long userId,
		OrderByComparator orderByComparator)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			BulkUploads[] array = new BulkUploadsImpl[3];

			array[0] = getByUserId_PrevAndNext(session, bulkUploads, userId,
					orderByComparator, true);

			array[1] = bulkUploads;

			array[2] = getByUserId_PrevAndNext(session, bulkUploads, userId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected BulkUploads getByUserId_PrevAndNext(Session session,
		BulkUploads bulkUploads, long userId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_BULKUPLOADS_WHERE);

		query.append(_FINDER_COLUMN_USERID_USERID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(BulkUploadsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(userId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(bulkUploads);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<BulkUploads> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the bulk uploadses where userId = &#63; from the database.
	 *
	 * @param userId the user ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUserId(long userId) throws SystemException {
		for (BulkUploads bulkUploads : findByUserId(userId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(bulkUploads);
		}
	}

	/**
	 * Returns the number of bulk uploadses where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @return the number of matching bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUserId(long userId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_USERID;

		Object[] finderArgs = new Object[] { userId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_BULKUPLOADS_WHERE);

			query.append(_FINDER_COLUMN_USERID_USERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERID_USERID_2 = "bulkUploads.userId = ?";

	public BulkUploadsPersistenceImpl() {
		setModelClass(BulkUploads.class);
	}

	/**
	 * Caches the bulk uploads in the entity cache if it is enabled.
	 *
	 * @param bulkUploads the bulk uploads
	 */
	@Override
	public void cacheResult(BulkUploads bulkUploads) {
		EntityCacheUtil.putResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsImpl.class, bulkUploads.getPrimaryKey(), bulkUploads);

		bulkUploads.resetOriginalValues();
	}

	/**
	 * Caches the bulk uploadses in the entity cache if it is enabled.
	 *
	 * @param bulkUploadses the bulk uploadses
	 */
	@Override
	public void cacheResult(List<BulkUploads> bulkUploadses) {
		for (BulkUploads bulkUploads : bulkUploadses) {
			if (EntityCacheUtil.getResult(
						BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
						BulkUploadsImpl.class, bulkUploads.getPrimaryKey()) == null) {
				cacheResult(bulkUploads);
			}
			else {
				bulkUploads.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all bulk uploadses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(BulkUploadsImpl.class.getName());
		}

		EntityCacheUtil.clearCache(BulkUploadsImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the bulk uploads.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(BulkUploads bulkUploads) {
		EntityCacheUtil.removeResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsImpl.class, bulkUploads.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<BulkUploads> bulkUploadses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (BulkUploads bulkUploads : bulkUploadses) {
			EntityCacheUtil.removeResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
				BulkUploadsImpl.class, bulkUploads.getPrimaryKey());
		}
	}

	/**
	 * Creates a new bulk uploads with the primary key. Does not add the bulk uploads to the database.
	 *
	 * @param id the primary key for the new bulk uploads
	 * @return the new bulk uploads
	 */
	@Override
	public BulkUploads create(long id) {
		BulkUploads bulkUploads = new BulkUploadsImpl();

		bulkUploads.setNew(true);
		bulkUploads.setPrimaryKey(id);

		String uuid = PortalUUIDUtil.generate();

		bulkUploads.setUuid(uuid);

		return bulkUploads;
	}

	/**
	 * Removes the bulk uploads with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the bulk uploads
	 * @return the bulk uploads that was removed
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads remove(long id)
		throws NoSuchBulkUploadsException, SystemException {
		return remove((Serializable)id);
	}

	/**
	 * Removes the bulk uploads with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the bulk uploads
	 * @return the bulk uploads that was removed
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads remove(Serializable primaryKey)
		throws NoSuchBulkUploadsException, SystemException {
		Session session = null;

		try {
			session = openSession();

			BulkUploads bulkUploads = (BulkUploads)session.get(BulkUploadsImpl.class,
					primaryKey);

			if (bulkUploads == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchBulkUploadsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(bulkUploads);
		}
		catch (NoSuchBulkUploadsException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected BulkUploads removeImpl(BulkUploads bulkUploads)
		throws SystemException {
		bulkUploads = toUnwrappedModel(bulkUploads);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(bulkUploads)) {
				bulkUploads = (BulkUploads)session.get(BulkUploadsImpl.class,
						bulkUploads.getPrimaryKeyObj());
			}

			if (bulkUploads != null) {
				session.delete(bulkUploads);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (bulkUploads != null) {
			clearCache(bulkUploads);
		}

		return bulkUploads;
	}

	@Override
	public BulkUploads updateImpl(com.ccm.model.BulkUploads bulkUploads)
		throws SystemException {
		bulkUploads = toUnwrappedModel(bulkUploads);

		boolean isNew = bulkUploads.isNew();

		BulkUploadsModelImpl bulkUploadsModelImpl = (BulkUploadsModelImpl)bulkUploads;

		if (Validator.isNull(bulkUploads.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			bulkUploads.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (bulkUploads.isNew()) {
				session.save(bulkUploads);

				bulkUploads.setNew(false);
			}
			else {
				session.merge(bulkUploads);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !BulkUploadsModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((bulkUploadsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bulkUploadsModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { bulkUploadsModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((bulkUploadsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CREDITCARDID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bulkUploadsModelImpl.getOriginalCreditCardId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CREDITCARDID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CREDITCARDID,
					args);

				args = new Object[] { bulkUploadsModelImpl.getCreditCardId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_CREDITCARDID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_CREDITCARDID,
					args);
			}

			if ((bulkUploadsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						bulkUploadsModelImpl.getOriginalUserId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
					args);

				args = new Object[] { bulkUploadsModelImpl.getUserId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
					args);
			}
		}

		EntityCacheUtil.putResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
			BulkUploadsImpl.class, bulkUploads.getPrimaryKey(), bulkUploads);

		return bulkUploads;
	}

	protected BulkUploads toUnwrappedModel(BulkUploads bulkUploads) {
		if (bulkUploads instanceof BulkUploadsImpl) {
			return bulkUploads;
		}

		BulkUploadsImpl bulkUploadsImpl = new BulkUploadsImpl();

		bulkUploadsImpl.setNew(bulkUploads.isNew());
		bulkUploadsImpl.setPrimaryKey(bulkUploads.getPrimaryKey());

		bulkUploadsImpl.setUuid(bulkUploads.getUuid());
		bulkUploadsImpl.setId(bulkUploads.getId());
		bulkUploadsImpl.setUploadDate(bulkUploads.getUploadDate());
		bulkUploadsImpl.setTimeTaken(bulkUploads.getTimeTaken());
		bulkUploadsImpl.setTotalRecords(bulkUploads.getTotalRecords());
		bulkUploadsImpl.setSuccessRecords(bulkUploads.getSuccessRecords());
		bulkUploadsImpl.setFailedRecords(bulkUploads.getFailedRecords());
		bulkUploadsImpl.setFileName(bulkUploads.getFileName());
		bulkUploadsImpl.setErrorFilePath(bulkUploads.getErrorFilePath());
		bulkUploadsImpl.setUserId(bulkUploads.getUserId());
		bulkUploadsImpl.setCreditCardId(bulkUploads.getCreditCardId());

		return bulkUploadsImpl;
	}

	/**
	 * Returns the bulk uploads with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the bulk uploads
	 * @return the bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByPrimaryKey(Serializable primaryKey)
		throws NoSuchBulkUploadsException, SystemException {
		BulkUploads bulkUploads = fetchByPrimaryKey(primaryKey);

		if (bulkUploads == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchBulkUploadsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return bulkUploads;
	}

	/**
	 * Returns the bulk uploads with the primary key or throws a {@link com.ccm.NoSuchBulkUploadsException} if it could not be found.
	 *
	 * @param id the primary key of the bulk uploads
	 * @return the bulk uploads
	 * @throws com.ccm.NoSuchBulkUploadsException if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads findByPrimaryKey(long id)
		throws NoSuchBulkUploadsException, SystemException {
		return findByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns the bulk uploads with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the bulk uploads
	 * @return the bulk uploads, or <code>null</code> if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		BulkUploads bulkUploads = (BulkUploads)EntityCacheUtil.getResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
				BulkUploadsImpl.class, primaryKey);

		if (bulkUploads == _nullBulkUploads) {
			return null;
		}

		if (bulkUploads == null) {
			Session session = null;

			try {
				session = openSession();

				bulkUploads = (BulkUploads)session.get(BulkUploadsImpl.class,
						primaryKey);

				if (bulkUploads != null) {
					cacheResult(bulkUploads);
				}
				else {
					EntityCacheUtil.putResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
						BulkUploadsImpl.class, primaryKey, _nullBulkUploads);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(BulkUploadsModelImpl.ENTITY_CACHE_ENABLED,
					BulkUploadsImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return bulkUploads;
	}

	/**
	 * Returns the bulk uploads with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the bulk uploads
	 * @return the bulk uploads, or <code>null</code> if a bulk uploads with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public BulkUploads fetchByPrimaryKey(long id) throws SystemException {
		return fetchByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns all the bulk uploadses.
	 *
	 * @return the bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the bulk uploadses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @return the range of bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the bulk uploadses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.BulkUploadsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of bulk uploadses
	 * @param end the upper bound of the range of bulk uploadses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<BulkUploads> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<BulkUploads> list = (List<BulkUploads>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_BULKUPLOADS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_BULKUPLOADS;

				if (pagination) {
					sql = sql.concat(BulkUploadsModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<BulkUploads>(list);
				}
				else {
					list = (List<BulkUploads>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the bulk uploadses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (BulkUploads bulkUploads : findAll()) {
			remove(bulkUploads);
		}
	}

	/**
	 * Returns the number of bulk uploadses.
	 *
	 * @return the number of bulk uploadses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_BULKUPLOADS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the bulk uploads persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.ccm.model.BulkUploads")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<BulkUploads>> listenersList = new ArrayList<ModelListener<BulkUploads>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<BulkUploads>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(BulkUploadsImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_BULKUPLOADS = "SELECT bulkUploads FROM BulkUploads bulkUploads";
	private static final String _SQL_SELECT_BULKUPLOADS_WHERE = "SELECT bulkUploads FROM BulkUploads bulkUploads WHERE ";
	private static final String _SQL_COUNT_BULKUPLOADS = "SELECT COUNT(bulkUploads) FROM BulkUploads bulkUploads";
	private static final String _SQL_COUNT_BULKUPLOADS_WHERE = "SELECT COUNT(bulkUploads) FROM BulkUploads bulkUploads WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "bulkUploads.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No BulkUploads exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No BulkUploads exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(BulkUploadsPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid", "id"
			});
	private static BulkUploads _nullBulkUploads = new BulkUploadsImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<BulkUploads> toCacheModel() {
				return _nullBulkUploadsCacheModel;
			}
		};

	private static CacheModel<BulkUploads> _nullBulkUploadsCacheModel = new CacheModel<BulkUploads>() {
			@Override
			public BulkUploads toEntityModel() {
				return _nullBulkUploads;
			}
		};
}