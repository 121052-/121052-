/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model.impl;

import com.ccm.model.Transactions;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Transactions in entity cache.
 *
 * @author Shreeya
 * @see Transactions
 * @generated
 */
public class TransactionsCacheModel implements CacheModel<Transactions>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", id=");
		sb.append(id);
		sb.append(", creditCardId=");
		sb.append(creditCardId);
		sb.append(", amount=");
		sb.append(amount);
		sb.append(", transactionDate=");
		sb.append(transactionDate);
		sb.append(", balance=");
		sb.append(balance);
		sb.append(", description=");
		sb.append(description);
		sb.append(", userId=");
		sb.append(userId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Transactions toEntityModel() {
		TransactionsImpl transactionsImpl = new TransactionsImpl();

		if (uuid == null) {
			transactionsImpl.setUuid(StringPool.BLANK);
		}
		else {
			transactionsImpl.setUuid(uuid);
		}

		transactionsImpl.setId(id);
		transactionsImpl.setCreditCardId(creditCardId);
		transactionsImpl.setAmount(amount);

		if (transactionDate == Long.MIN_VALUE) {
			transactionsImpl.setTransactionDate(null);
		}
		else {
			transactionsImpl.setTransactionDate(new Date(transactionDate));
		}

		transactionsImpl.setBalance(balance);

		if (description == null) {
			transactionsImpl.setDescription(StringPool.BLANK);
		}
		else {
			transactionsImpl.setDescription(description);
		}

		transactionsImpl.setUserId(userId);

		transactionsImpl.resetOriginalValues();

		return transactionsImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		id = objectInput.readLong();
		creditCardId = objectInput.readLong();
		amount = objectInput.readDouble();
		transactionDate = objectInput.readLong();
		balance = objectInput.readDouble();
		description = objectInput.readUTF();
		userId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(id);
		objectOutput.writeLong(creditCardId);
		objectOutput.writeDouble(amount);
		objectOutput.writeLong(transactionDate);
		objectOutput.writeDouble(balance);

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}

		objectOutput.writeLong(userId);
	}

	public String uuid;
	public long id;
	public long creditCardId;
	public double amount;
	public long transactionDate;
	public double balance;
	public String description;
	public long userId;
}