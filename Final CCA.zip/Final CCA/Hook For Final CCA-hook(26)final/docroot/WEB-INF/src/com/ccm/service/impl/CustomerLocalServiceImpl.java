/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.beanutils.BeanUtils;

import com.ccm.DTO.CustomerDetails;
import com.ccm.service.base.CustomerLocalServiceBaseImpl;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.PhoneLocalServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;

/**
 * The implementation of the customer local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are
 * added, rerun ServiceBuilder to copy their definitions into the
 * {@link com.ccm.service.CustomerLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security
 * checks based on the propagated JAAS credentials because this service can only
 * be accessed from within the same VM.
 * </p>
 *
 * @author Shreeya
 * @see com.ccm.service.base.CustomerLocalServiceBaseImpl
 * @see com.ccm.service.CustomerLocalServiceUtil
 */
public class CustomerLocalServiceImpl extends CustomerLocalServiceBaseImpl {

	long userIdUpdate = 0;
	
	public boolean checkAdmin(long userId, long companyId) throws PortalException, SystemException {
	
		Role adminRole = RoleLocalServiceUtil.getRole(companyId, "Administrator");
		User user = UserLocalServiceUtil.getUser(userId);
		List<Role> roles = user.getRoles();
		if (Validator.isNotNull(roles) && roles.contains(adminRole)) {
			return true;
		} else {
			return false;
		}
	}

	public CustomerDetails checkCustomer(long companyId, String emailAddress, String password) {
		CustomerDetails cd = null;
		try {
			User userfindby = UserLocalServiceUtil.getUserByEmailAddress(companyId, emailAddress);

			String password_1 = userfindby.getPassword();
			if (password_1.equals(password)) {
				cd = new CustomerDetails();
				BeanUtils.copyProperties(cd, userfindby);
				for (Address add : userfindby.getAddresses()) {
					BeanUtils.copyProperties(cd, add);
				}
				BeanUtils.copyProperties(cd, userfindby.getContact());
				for (Phone phone : userfindby.getPhones()) {
					BeanUtils.copyProperties(cd, phone);
				}
				return cd;
			} else {
				System.out.println("UserName or Passwork is unvalid");
			}
			return null;
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public List<CustomerDetails> returnCustomerList(List<User> userList, List<Address> addList,
			List<CustomerDetails> custList) throws SystemException {
		CustomerDetails customerList = null;
		try {
			for (User user : userList) {
				customerList = new CustomerDetails();
				BeanUtils.copyProperties(customerList, user);
				for (Address add : user.getAddresses()) {
					BeanUtils.copyProperties(customerList, add);
				}
				BeanUtils.copyProperties(customerList, user.getContact());
				for (Phone phone : user.getPhones()) {
					BeanUtils.copyProperties(customerList, phone);
				}
				custList.add(customerList);
			}
		} catch (Exception e) {// System.out.println("error "+e);
		}

		return custList;
	}

	public List<CustomerDetails> showCustomerList() {
		CustomerDetails c = null;
		List<User> userList = null;
		List<CustomerDetails> custList = new ArrayList<CustomerDetails>();
		try {
			userList = UserLocalServiceUtil.getUsers(-1, -1);
			for (User user : userList) {
				c = new CustomerDetails();

				// ConvertUtils.register(new DateConverter(null), Date.class);
				try {
					BeanUtils.copyProperties(c, user.getContact());
					// System.out.println("addreses: "+user.getAddresses());

					List<Address> addressList = AddressLocalServiceUtil.getAddresses(-1, -1);
					for (int i = 0; i < addressList.size(); i++) {
						if (user.getUserId() == addressList.get(i).getUserId()) {
							BeanUtils.copyProperties(c, addressList.get(i));
						}
					}
					// this is first logic or alternative to above for loop

					/*
					 * if(user.getAddresses() != null){ for (Address address :
					 * user.getAddresses()) {
					 * 
					 * BeanUtils.copyProperties(c, address);
					 * 
					 * } }
					 */

					List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);
					for (int i = 0; i < phoneList.size(); i++) {
						if (user.getUserId() == phoneList.get(i).getUserId()) {
							BeanUtils.copyProperties(c, phoneList.get(i));
						}
					}
					// this is first logic or alternative to above for loop
					/*
					 * if(user.getPhones() != null){ for (Phone phone :
					 * user.getPhones()) { BeanUtils.copyProperties(c, phone); }
					 * }
					 */

					BeanUtils.copyProperties(c, user);
				} catch (InvocationTargetException exception) {
					exception.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
				custList.add(c);
			}
		} catch (SystemException e) {// System.out.println("error "+e);

		} catch (PortalException e) {// System.out.println("error "+e);
		}
		return custList;
	}

	public void addCustomerDetails(CustomerDetails c, ThemeDisplay display) {

		long userIdExist = c.getUserId();
		Calendar cal = Calendar.getInstance();
		Date dob = c.getBirthday();
		cal.setTime(dob);
		int birthdayMonth = cal.get(Calendar.MONTH) + 1;
		int birthdayYear = cal.get(Calendar.YEAR);
		int birthdayDay = cal.get(Calendar.DAY_OF_MONTH);

		long[] groupIds = new long[1];
		groupIds[0] = display.getCompanyGroupId();
		long[] organizationIds = new long[1];
		organizationIds[0] = 10902;
		long[] userGroupIds = new long[0];
		long[] roleIds = new long[1];

		Role r;
		try {
			User user = UserLocalServiceUtil.createUser(CounterLocalServiceUtil.increment());
			BeanUtils.copyProperties(user, c);
			r = RoleLocalServiceUtil.getRole(10155, "User");
			roleIds[0] = (long) r.getRoleId();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (PortalException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ServiceContext serviceContext = new ServiceContext();
		Locale Locale = display.getLocale();
		long creatorUserId = display.getUserId();
		long companyId = 10155;
		String password1 = "test";
		String password2 = password1;
		String screenName = c.getScreenName();
		String emailAddress = c.getEmailAddress();
		long facebookId = -1;
		String openId = null;
		String firstName = c.getFirstName();
		String middleName = null;
		String lastName = c.getLastName();
		int prefixId = -1;
		int suffixId = -1;
		boolean male = true;
		String jobTitle = null;
		boolean sendEmail = false;
		try {
			// System.out.println(userIdExist + " " + c.getUserId());
			if (userIdExist != 0) {
				userIdUpdate = c.getUserId();
				User oldUserDetails = UserLocalServiceUtil.getUser(c.getUserId());
				oldUserDetails.setFirstName(firstName);
				oldUserDetails.setLastName(lastName);
				oldUserDetails.setScreenName(screenName);
				oldUserDetails.setEmailAddress(emailAddress);
				UserLocalServiceUtil.updateUser(oldUserDetails);

			} else {

				UserLocalServiceUtil.addUser(creatorUserId, companyId, false, password1, password2, false, screenName,
						emailAddress, facebookId, openId, Locale, firstName, middleName, lastName, prefixId, suffixId,
						male, birthdayMonth, birthdayDay, birthdayYear, jobTitle, groupIds, organizationIds, roleIds,
						userGroupIds, sendEmail, serviceContext);

				System.out.println("This is add ");
			}

		} catch (PortalException e) {
			System.out.println("PortalException: " + e);
			// TODO Auto-generated catch block
			// e.printStackTrace();
		} catch (SystemException e) {
			System.out.println("SystemException: " + e);
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

	public void addCustomerAddress(CustomerDetails c) {
		long userIdExist = c.getUserId();
		User u = null;
		long creatorUserId = 0;
		String fName = c.getFirstName();
		String lName = c.getLastName();
		try {

			if (userIdExist != 0) {

				long addressId = 0;
				List<Address> addressList = AddressLocalServiceUtil.getAddresses(-1, -1);

				for (Address address : addressList) {
					if(address.getUserId() == c.getUserId()){
						addressId = address.getAddressId();
					}
				}
				if (addressId != 0) {
					
					Address ad1 = AddressLocalServiceUtil.getAddress(addressId);
					ad1.setStreet1(c.getStreet1());
					ad1.setCity(c.getCity());
					ad1.setZip(c.getZip());
					ad1.setUserName(c.getFirstName() + " " + c.getLastName());
					AddressLocalServiceUtil.updateAddress(ad1);
				} else {
					u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
					creatorUserId = u.getUserId();
					Address ad = AddressLocalServiceUtil.createAddress(CounterLocalServiceUtil.increment());
					// ad.setAddressId(CounterLocalServiceUtil.increment());
					ad.setStreet1(c.getStreet1());
					ad.setCity(c.getCity());
					ad.setZip(c.getZip());
					ad.setUserId(creatorUserId);
					ad.setCompanyId(10155);
					ad.setUserName(fName + " " + lName);
					AddressLocalServiceUtil.addAddress(ad);
				}

			} else {

				// long groupId = CounterLocalServiceUtil.increment();
				// Group g =
				// GroupLocalServiceUtil.createGroup(CounterLocalServiceUtil.increment());
				// g.setGroupId(groupId);
				// g.setCompanyId(10155);
				// g.setClassNameId(10005);
				// g.setClassPK(creatorUserId);
				// g.setCreatorUserId(creatorUserId);
				// g.setName(String.valueOf(groupId - 3));
				// g.setTreePath("/" + String.valueOf(groupId) + "/");
				u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
				// g.setFriendlyURL("/" + u.getScreenName());
				// GroupLocalServiceUtil.addGroup(g);

				creatorUserId = u.getUserId();
				Address ad = AddressLocalServiceUtil.createAddress(CounterLocalServiceUtil.increment());
				// ad.setAddressId(CounterLocalServiceUtil.increment());
				ad.setStreet1(c.getStreet1());
				ad.setCity(c.getCity());
				ad.setZip(c.getZip());
				ad.setUserId(creatorUserId);
				ad.setCompanyId(10155);
				ad.setUserName(fName + " " + lName);
				AddressLocalServiceUtil.addAddress(ad);
			}
		} catch (SystemException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addCustomerPhone(CustomerDetails c) {
		long userIdExist = c.getUserId();
		User u = null;
		long creatorUserId = 0;
		String fName = c.getFirstName();
		String lName = c.getLastName();

		try {
			if (userIdExist != 0) {
				long phoneId = 0;
				List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);

				for (Phone phone : phoneList) {
					if(phone.getUserId() == c.getUserId()){
					
						phoneId=phone.getPhoneId();
					}
				}
							
				if (phoneId != 0) {
					Phone phoneToUpdate = PhoneLocalServiceUtil.getPhone(phoneId);
					phoneToUpdate.setNumber(c.getNumber());
					phoneToUpdate.setUserName(fName + " " + lName);
					PhoneLocalServiceUtil.updatePhone(phoneToUpdate);
				} else {
					u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
					creatorUserId = u.getUserId();
					Phone p = PhoneLocalServiceUtil.createPhone(CounterLocalServiceUtil.increment());
					// p.setPhoneId(CounterLocalServiceUtil.increment());
					p.setUserId(creatorUserId);
					p.setNumber(c.getNumber());
					p.setCompanyId(10155);
					p.setUserName(fName + " " + lName);
					PhoneLocalServiceUtil.addPhone(p);
				}

			} else {
				u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
				creatorUserId = u.getUserId();
				Phone p = PhoneLocalServiceUtil.createPhone(CounterLocalServiceUtil.increment());
				// p.setPhoneId(CounterLocalServiceUtil.increment());
				p.setUserId(creatorUserId);
				p.setNumber(c.getNumber());
				p.setCompanyId(10155);
				p.setUserName(fName + " " + lName);
				PhoneLocalServiceUtil.addPhone(p);
			}
		} catch (SystemException e) {
			// System.out.println(e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void addCustomerContact(CustomerDetails c) {
		// TODO Auto-generated method stub
		
	}

	
//	public void addCustomerContact(CustomerDetails c) {
//		long userIdExist = c.getUserId();
//		User u = null;
//		long creatorUserId = 0;
//		long contactId = 0;
//		String fName = c.getFirstName();
//		String lName = c.getLastName();
//		try {
//
//			if (userIdExist != 0) {
//				u = UserLocalServiceUtil.getUserById(userIdUpdate);
//				if (Validator.isNotNull(u.getContactId())) {
//					contactId = u.getContactId();
//					Contact contact = ContactLocalServiceUtil.getContact(contactId);
//					contact.setUserName(fName + " " + lName);
//					contact.setEmailAddress(c.getEmailAddress());
//					contact.setFirstName(fName);
//					contact.setLastName(lName);
//					contact.setBirthday(c.getBirthday());
//					ContactLocalServiceUtil.updateContact(contact);
//				} else {
//					u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
//					creatorUserId = u.getUserId();
//					Contact contact = ContactLocalServiceUtil.createContact(CounterLocalServiceUtil.increment());
//					// contact.setContactId(CounterLocalServiceUtil.increment());
//					contact.setCompanyId(10155);
//					contact.setUserId(creatorUserId);
//					contact.setUserName(fName + " " + lName);
//					contact.setAccountId(10157);
//					contact.setEmailAddress(c.getEmailAddress());
//					contact.setFirstName(fName);
//					contact.setLastName(lName);
//					contact.setBirthday(c.getBirthday());
//					ContactLocalServiceUtil.addContact(contact);
//				}
//
//			} else {
//				u = UserLocalServiceUtil.getUserByScreenName(10155, c.getScreenName());
//				creatorUserId = u.getUserId();
//				Contact contact = ContactLocalServiceUtil.createContact(CounterLocalServiceUtil.increment());
//				// contact.setContactId(CounterLocalServiceUtil.increment());
//				contact.setCompanyId(10155);
//				contact.setUserId(creatorUserId);
//				contact.setUserName(fName + " " + lName);
//				contact.setAccountId(10157);
//				contact.setEmailAddress(c.getEmailAddress());
//				contact.setFirstName(fName);
//				contact.setLastName(lName);
//				contact.setBirthday(c.getBirthday());
//				ContactLocalServiceUtil.addContact(contact);
//			}
//		} catch (SystemException e) {
//			// System.out.println(e);
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (PortalException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}
}