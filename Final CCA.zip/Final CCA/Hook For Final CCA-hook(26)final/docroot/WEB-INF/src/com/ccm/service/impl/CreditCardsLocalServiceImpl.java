/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.impl;

import java.util.List;

import com.ccm.NoSuchCreditCardsException;
import com.ccm.model.CreditCards;
import com.ccm.service.base.CreditCardsLocalServiceBaseImpl;
import com.liferay.portal.kernel.exception.SystemException;

/**
 * The implementation of the credit cards local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are
 * added, rerun ServiceBuilder to copy their definitions into the
 * {@link com.ccm.service.CreditCardsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security
 * checks based on the propagated JAAS credentials because this service can only
 * be accessed from within the same VM.
 * </p>
 *
 * @author Shreeya
 * @see com.ccm.service.base.CreditCardsLocalServiceBaseImpl
 * @see com.ccm.service.CreditCardsLocalServiceUtil
 */
public class CreditCardsLocalServiceImpl extends CreditCardsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link
	 * com.ccm.service.CreditCardsLocalServiceUtil} to access the credit cards
	 * local service.
	 */
	public List<CreditCards> getCreditCardHolder(long userId) throws SystemException {
		return creditCardsPersistence.findByUserId(userId);
	}
	
	public CreditCards getCreditCardId(long userId, String cardNumber) throws SystemException, NoSuchCreditCardsException{
		return creditCardsPersistence.findByUserIdCardNumber(userId, cardNumber);
	}
		
}