/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.model.impl;

import com.ccm.model.Statement;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Statement in entity cache.
 *
 * @author Shreeya
 * @see Statement
 * @generated
 */
public class StatementCacheModel implements CacheModel<Statement>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", id=");
		sb.append(id);
		sb.append(", creditCardId=");
		sb.append(creditCardId);
		sb.append(", statementDate=");
		sb.append(statementDate);
		sb.append(", fromDate=");
		sb.append(fromDate);
		sb.append(", toDate=");
		sb.append(toDate);
		sb.append(", amountDue=");
		sb.append(amountDue);
		sb.append(", statementFilePath=");
		sb.append(statementFilePath);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Statement toEntityModel() {
		StatementImpl statementImpl = new StatementImpl();

		if (uuid == null) {
			statementImpl.setUuid(StringPool.BLANK);
		}
		else {
			statementImpl.setUuid(uuid);
		}

		statementImpl.setId(id);
		statementImpl.setCreditCardId(creditCardId);

		if (statementDate == Long.MIN_VALUE) {
			statementImpl.setStatementDate(null);
		}
		else {
			statementImpl.setStatementDate(new Date(statementDate));
		}

		if (fromDate == Long.MIN_VALUE) {
			statementImpl.setFromDate(null);
		}
		else {
			statementImpl.setFromDate(new Date(fromDate));
		}

		if (toDate == Long.MIN_VALUE) {
			statementImpl.setToDate(null);
		}
		else {
			statementImpl.setToDate(new Date(toDate));
		}

		statementImpl.setAmountDue(amountDue);

		if (statementFilePath == null) {
			statementImpl.setStatementFilePath(StringPool.BLANK);
		}
		else {
			statementImpl.setStatementFilePath(statementFilePath);
		}

		statementImpl.resetOriginalValues();

		return statementImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		id = objectInput.readLong();
		creditCardId = objectInput.readLong();
		statementDate = objectInput.readLong();
		fromDate = objectInput.readLong();
		toDate = objectInput.readLong();
		amountDue = objectInput.readDouble();
		statementFilePath = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(id);
		objectOutput.writeLong(creditCardId);
		objectOutput.writeLong(statementDate);
		objectOutput.writeLong(fromDate);
		objectOutput.writeLong(toDate);
		objectOutput.writeDouble(amountDue);

		if (statementFilePath == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(statementFilePath);
		}
	}

	public String uuid;
	public long id;
	public long creditCardId;
	public long statementDate;
	public long fromDate;
	public long toDate;
	public double amountDue;
	public String statementFilePath;
}