/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.ccm.service.persistence;

import com.ccm.NoSuchCreditCardsException;

import com.ccm.model.CreditCards;
import com.ccm.model.impl.CreditCardsImpl;
import com.ccm.model.impl.CreditCardsModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the credit cards service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Shreeya
 * @see CreditCardsPersistence
 * @see CreditCardsUtil
 * @generated
 */
public class CreditCardsPersistenceImpl extends BasePersistenceImpl<CreditCards>
	implements CreditCardsPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link CreditCardsUtil} to access the credit cards persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = CreditCardsImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			CreditCardsModelImpl.UUID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the credit cardses where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the credit cardses where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @return the range of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the credit cardses where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<CreditCards> list = (List<CreditCards>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (CreditCards creditCards : list) {
				if (!Validator.equals(uuid, creditCards.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CREDITCARDS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(CreditCardsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<CreditCards>(list);
				}
				else {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first credit cards in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByUuid_First(uuid, orderByComparator);

		if (creditCards != null) {
			return creditCards;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchCreditCardsException(msg.toString());
	}

	/**
	 * Returns the first credit cards in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<CreditCards> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last credit cards in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByUuid_Last(uuid, orderByComparator);

		if (creditCards != null) {
			return creditCards;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchCreditCardsException(msg.toString());
	}

	/**
	 * Returns the last credit cards in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<CreditCards> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the credit cardses before and after the current credit cards in the ordered set where uuid = &#63;.
	 *
	 * @param id the primary key of the current credit cards
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards[] findByUuid_PrevAndNext(long id, String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			CreditCards[] array = new CreditCardsImpl[3];

			array[0] = getByUuid_PrevAndNext(session, creditCards, uuid,
					orderByComparator, true);

			array[1] = creditCards;

			array[2] = getByUuid_PrevAndNext(session, creditCards, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CreditCards getByUuid_PrevAndNext(Session session,
		CreditCards creditCards, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CREDITCARDS_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CreditCardsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(creditCards);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<CreditCards> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the credit cardses where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (CreditCards creditCards : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(creditCards);
		}
	}

	/**
	 * Returns the number of credit cardses where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CREDITCARDS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "creditCards.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "creditCards.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(creditCards.uuid IS NULL OR creditCards.uuid = '')";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUserId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID =
		new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUserId",
			new String[] { Long.class.getName() },
			CreditCardsModelImpl.USERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_USERID = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUserId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the credit cardses where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @return the matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUserId(long userId)
		throws SystemException {
		return findByUserId(userId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the credit cardses where userId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @return the range of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUserId(long userId, int start, int end)
		throws SystemException {
		return findByUserId(userId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the credit cardses where userId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findByUserId(long userId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID;
			finderArgs = new Object[] { userId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_USERID;
			finderArgs = new Object[] { userId, start, end, orderByComparator };
		}

		List<CreditCards> list = (List<CreditCards>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (CreditCards creditCards : list) {
				if ((userId != creditCards.getUserId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_CREDITCARDS_WHERE);

			query.append(_FINDER_COLUMN_USERID_USERID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(CreditCardsModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				if (!pagination) {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<CreditCards>(list);
				}
				else {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first credit cards in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByUserId_First(long userId,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByUserId_First(userId, orderByComparator);

		if (creditCards != null) {
			return creditCards;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchCreditCardsException(msg.toString());
	}

	/**
	 * Returns the first credit cards in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUserId_First(long userId,
		OrderByComparator orderByComparator) throws SystemException {
		List<CreditCards> list = findByUserId(userId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last credit cards in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByUserId_Last(long userId,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByUserId_Last(userId, orderByComparator);

		if (creditCards != null) {
			return creditCards;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchCreditCardsException(msg.toString());
	}

	/**
	 * Returns the last credit cards in the ordered set where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUserId_Last(long userId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUserId(userId);

		if (count == 0) {
			return null;
		}

		List<CreditCards> list = findByUserId(userId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the credit cardses before and after the current credit cards in the ordered set where userId = &#63;.
	 *
	 * @param id the primary key of the current credit cards
	 * @param userId the user ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards[] findByUserId_PrevAndNext(long id, long userId,
		OrderByComparator orderByComparator)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = findByPrimaryKey(id);

		Session session = null;

		try {
			session = openSession();

			CreditCards[] array = new CreditCardsImpl[3];

			array[0] = getByUserId_PrevAndNext(session, creditCards, userId,
					orderByComparator, true);

			array[1] = creditCards;

			array[2] = getByUserId_PrevAndNext(session, creditCards, userId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected CreditCards getByUserId_PrevAndNext(Session session,
		CreditCards creditCards, long userId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_CREDITCARDS_WHERE);

		query.append(_FINDER_COLUMN_USERID_USERID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(CreditCardsModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(userId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(creditCards);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<CreditCards> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the credit cardses where userId = &#63; from the database.
	 *
	 * @param userId the user ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUserId(long userId) throws SystemException {
		for (CreditCards creditCards : findByUserId(userId, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(creditCards);
		}
	}

	/**
	 * Returns the number of credit cardses where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @return the number of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUserId(long userId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_USERID;

		Object[] finderArgs = new Object[] { userId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_CREDITCARDS_WHERE);

			query.append(_FINDER_COLUMN_USERID_USERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERID_USERID_2 = "creditCards.userId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_USERIDCARDNUMBER = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, CreditCardsImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByUserIdCardNumber",
			new String[] { Long.class.getName(), String.class.getName() },
			CreditCardsModelImpl.USERID_COLUMN_BITMASK |
			CreditCardsModelImpl.CARDNUMBER_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_USERIDCARDNUMBER = new FinderPath(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByUserIdCardNumber",
			new String[] { Long.class.getName(), String.class.getName() });

	/**
	 * Returns the credit cards where userId = &#63; and cardNumber = &#63; or throws a {@link com.ccm.NoSuchCreditCardsException} if it could not be found.
	 *
	 * @param userId the user ID
	 * @param cardNumber the card number
	 * @return the matching credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByUserIdCardNumber(long userId, String cardNumber)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByUserIdCardNumber(userId, cardNumber);

		if (creditCards == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("userId=");
			msg.append(userId);

			msg.append(", cardNumber=");
			msg.append(cardNumber);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchCreditCardsException(msg.toString());
		}

		return creditCards;
	}

	/**
	 * Returns the credit cards where userId = &#63; and cardNumber = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param userId the user ID
	 * @param cardNumber the card number
	 * @return the matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUserIdCardNumber(long userId, String cardNumber)
		throws SystemException {
		return fetchByUserIdCardNumber(userId, cardNumber, true);
	}

	/**
	 * Returns the credit cards where userId = &#63; and cardNumber = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param userId the user ID
	 * @param cardNumber the card number
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching credit cards, or <code>null</code> if a matching credit cards could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByUserIdCardNumber(long userId, String cardNumber,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { userId, cardNumber };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
					finderArgs, this);
		}

		if (result instanceof CreditCards) {
			CreditCards creditCards = (CreditCards)result;

			if ((userId != creditCards.getUserId()) ||
					!Validator.equals(cardNumber, creditCards.getCardNumber())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_CREDITCARDS_WHERE);

			query.append(_FINDER_COLUMN_USERIDCARDNUMBER_USERID_2);

			boolean bindCardNumber = false;

			if (cardNumber == null) {
				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_1);
			}
			else if (cardNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_3);
			}
			else {
				bindCardNumber = true;

				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				if (bindCardNumber) {
					qPos.add(cardNumber);
				}

				List<CreditCards> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"CreditCardsPersistenceImpl.fetchByUserIdCardNumber(long, String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					CreditCards creditCards = list.get(0);

					result = creditCards;

					cacheResult(creditCards);

					if ((creditCards.getUserId() != userId) ||
							(creditCards.getCardNumber() == null) ||
							!creditCards.getCardNumber().equals(cardNumber)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
							finderArgs, creditCards);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (CreditCards)result;
		}
	}

	/**
	 * Removes the credit cards where userId = &#63; and cardNumber = &#63; from the database.
	 *
	 * @param userId the user ID
	 * @param cardNumber the card number
	 * @return the credit cards that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards removeByUserIdCardNumber(long userId, String cardNumber)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = findByUserIdCardNumber(userId, cardNumber);

		return remove(creditCards);
	}

	/**
	 * Returns the number of credit cardses where userId = &#63; and cardNumber = &#63;.
	 *
	 * @param userId the user ID
	 * @param cardNumber the card number
	 * @return the number of matching credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUserIdCardNumber(long userId, String cardNumber)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_USERIDCARDNUMBER;

		Object[] finderArgs = new Object[] { userId, cardNumber };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_CREDITCARDS_WHERE);

			query.append(_FINDER_COLUMN_USERIDCARDNUMBER_USERID_2);

			boolean bindCardNumber = false;

			if (cardNumber == null) {
				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_1);
			}
			else if (cardNumber.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_3);
			}
			else {
				bindCardNumber = true;

				query.append(_FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				if (bindCardNumber) {
					qPos.add(cardNumber);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERIDCARDNUMBER_USERID_2 = "creditCards.userId = ? AND ";
	private static final String _FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_1 = "creditCards.cardNumber IS NULL";
	private static final String _FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_2 = "creditCards.cardNumber = ?";
	private static final String _FINDER_COLUMN_USERIDCARDNUMBER_CARDNUMBER_3 = "(creditCards.cardNumber IS NULL OR creditCards.cardNumber = '')";

	public CreditCardsPersistenceImpl() {
		setModelClass(CreditCards.class);
	}

	/**
	 * Caches the credit cards in the entity cache if it is enabled.
	 *
	 * @param creditCards the credit cards
	 */
	@Override
	public void cacheResult(CreditCards creditCards) {
		EntityCacheUtil.putResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsImpl.class, creditCards.getPrimaryKey(), creditCards);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
			new Object[] { creditCards.getUserId(), creditCards.getCardNumber() },
			creditCards);

		creditCards.resetOriginalValues();
	}

	/**
	 * Caches the credit cardses in the entity cache if it is enabled.
	 *
	 * @param creditCardses the credit cardses
	 */
	@Override
	public void cacheResult(List<CreditCards> creditCardses) {
		for (CreditCards creditCards : creditCardses) {
			if (EntityCacheUtil.getResult(
						CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
						CreditCardsImpl.class, creditCards.getPrimaryKey()) == null) {
				cacheResult(creditCards);
			}
			else {
				creditCards.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all credit cardses.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(CreditCardsImpl.class.getName());
		}

		EntityCacheUtil.clearCache(CreditCardsImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the credit cards.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(CreditCards creditCards) {
		EntityCacheUtil.removeResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsImpl.class, creditCards.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(creditCards);
	}

	@Override
	public void clearCache(List<CreditCards> creditCardses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (CreditCards creditCards : creditCardses) {
			EntityCacheUtil.removeResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
				CreditCardsImpl.class, creditCards.getPrimaryKey());

			clearUniqueFindersCache(creditCards);
		}
	}

	protected void cacheUniqueFindersCache(CreditCards creditCards) {
		if (creditCards.isNew()) {
			Object[] args = new Object[] {
					creditCards.getUserId(), creditCards.getCardNumber()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_USERIDCARDNUMBER,
				args, Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
				args, creditCards);
		}
		else {
			CreditCardsModelImpl creditCardsModelImpl = (CreditCardsModelImpl)creditCards;

			if ((creditCardsModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_USERIDCARDNUMBER.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						creditCards.getUserId(), creditCards.getCardNumber()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_USERIDCARDNUMBER,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
					args, creditCards);
			}
		}
	}

	protected void clearUniqueFindersCache(CreditCards creditCards) {
		CreditCardsModelImpl creditCardsModelImpl = (CreditCardsModelImpl)creditCards;

		Object[] args = new Object[] {
				creditCards.getUserId(), creditCards.getCardNumber()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERIDCARDNUMBER, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER, args);

		if ((creditCardsModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_USERIDCARDNUMBER.getColumnBitmask()) != 0) {
			args = new Object[] {
					creditCardsModelImpl.getOriginalUserId(),
					creditCardsModelImpl.getOriginalCardNumber()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERIDCARDNUMBER,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERIDCARDNUMBER,
				args);
		}
	}

	/**
	 * Creates a new credit cards with the primary key. Does not add the credit cards to the database.
	 *
	 * @param id the primary key for the new credit cards
	 * @return the new credit cards
	 */
	@Override
	public CreditCards create(long id) {
		CreditCards creditCards = new CreditCardsImpl();

		creditCards.setNew(true);
		creditCards.setPrimaryKey(id);

		String uuid = PortalUUIDUtil.generate();

		creditCards.setUuid(uuid);

		return creditCards;
	}

	/**
	 * Removes the credit cards with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param id the primary key of the credit cards
	 * @return the credit cards that was removed
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards remove(long id)
		throws NoSuchCreditCardsException, SystemException {
		return remove((Serializable)id);
	}

	/**
	 * Removes the credit cards with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the credit cards
	 * @return the credit cards that was removed
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards remove(Serializable primaryKey)
		throws NoSuchCreditCardsException, SystemException {
		Session session = null;

		try {
			session = openSession();

			CreditCards creditCards = (CreditCards)session.get(CreditCardsImpl.class,
					primaryKey);

			if (creditCards == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchCreditCardsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(creditCards);
		}
		catch (NoSuchCreditCardsException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected CreditCards removeImpl(CreditCards creditCards)
		throws SystemException {
		creditCards = toUnwrappedModel(creditCards);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(creditCards)) {
				creditCards = (CreditCards)session.get(CreditCardsImpl.class,
						creditCards.getPrimaryKeyObj());
			}

			if (creditCards != null) {
				session.delete(creditCards);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (creditCards != null) {
			clearCache(creditCards);
		}

		return creditCards;
	}

	@Override
	public CreditCards updateImpl(com.ccm.model.CreditCards creditCards)
		throws SystemException {
		creditCards = toUnwrappedModel(creditCards);

		boolean isNew = creditCards.isNew();

		CreditCardsModelImpl creditCardsModelImpl = (CreditCardsModelImpl)creditCards;

		if (Validator.isNull(creditCards.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			creditCards.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (creditCards.isNew()) {
				session.save(creditCards);

				creditCards.setNew(false);
			}
			else {
				session.merge(creditCards);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !CreditCardsModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((creditCardsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						creditCardsModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { creditCardsModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((creditCardsModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						creditCardsModelImpl.getOriginalUserId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
					args);

				args = new Object[] { creditCardsModelImpl.getUserId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERID,
					args);
			}
		}

		EntityCacheUtil.putResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
			CreditCardsImpl.class, creditCards.getPrimaryKey(), creditCards);

		clearUniqueFindersCache(creditCards);
		cacheUniqueFindersCache(creditCards);

		return creditCards;
	}

	protected CreditCards toUnwrappedModel(CreditCards creditCards) {
		if (creditCards instanceof CreditCardsImpl) {
			return creditCards;
		}

		CreditCardsImpl creditCardsImpl = new CreditCardsImpl();

		creditCardsImpl.setNew(creditCards.isNew());
		creditCardsImpl.setPrimaryKey(creditCards.getPrimaryKey());

		creditCardsImpl.setUuid(creditCards.getUuid());
		creditCardsImpl.setId(creditCards.getId());
		creditCardsImpl.setCardNumber(creditCards.getCardNumber());
		creditCardsImpl.setValidFromDate(creditCards.getValidFromDate());
		creditCardsImpl.setValidToDate(creditCards.getValidToDate());
		creditCardsImpl.setCvv(creditCards.getCvv());
		creditCardsImpl.setNameOnCard(creditCards.getNameOnCard());
		creditCardsImpl.setStatementDate(creditCards.getStatementDate());
		creditCardsImpl.setUserId(creditCards.getUserId());
		creditCardsImpl.setCreditLimit(creditCards.getCreditLimit());
		creditCardsImpl.setAvailableCreditLimit(creditCards.getAvailableCreditLimit());
		creditCardsImpl.setRoyalty_points(creditCards.getRoyalty_points());

		return creditCardsImpl;
	}

	/**
	 * Returns the credit cards with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the credit cards
	 * @return the credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByPrimaryKey(Serializable primaryKey)
		throws NoSuchCreditCardsException, SystemException {
		CreditCards creditCards = fetchByPrimaryKey(primaryKey);

		if (creditCards == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchCreditCardsException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return creditCards;
	}

	/**
	 * Returns the credit cards with the primary key or throws a {@link com.ccm.NoSuchCreditCardsException} if it could not be found.
	 *
	 * @param id the primary key of the credit cards
	 * @return the credit cards
	 * @throws com.ccm.NoSuchCreditCardsException if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards findByPrimaryKey(long id)
		throws NoSuchCreditCardsException, SystemException {
		return findByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns the credit cards with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the credit cards
	 * @return the credit cards, or <code>null</code> if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		CreditCards creditCards = (CreditCards)EntityCacheUtil.getResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
				CreditCardsImpl.class, primaryKey);

		if (creditCards == _nullCreditCards) {
			return null;
		}

		if (creditCards == null) {
			Session session = null;

			try {
				session = openSession();

				creditCards = (CreditCards)session.get(CreditCardsImpl.class,
						primaryKey);

				if (creditCards != null) {
					cacheResult(creditCards);
				}
				else {
					EntityCacheUtil.putResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
						CreditCardsImpl.class, primaryKey, _nullCreditCards);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(CreditCardsModelImpl.ENTITY_CACHE_ENABLED,
					CreditCardsImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return creditCards;
	}

	/**
	 * Returns the credit cards with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param id the primary key of the credit cards
	 * @return the credit cards, or <code>null</code> if a credit cards with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public CreditCards fetchByPrimaryKey(long id) throws SystemException {
		return fetchByPrimaryKey((Serializable)id);
	}

	/**
	 * Returns all the credit cardses.
	 *
	 * @return the credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the credit cardses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @return the range of credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the credit cardses.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.ccm.model.impl.CreditCardsModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of credit cardses
	 * @param end the upper bound of the range of credit cardses (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<CreditCards> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<CreditCards> list = (List<CreditCards>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_CREDITCARDS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_CREDITCARDS;

				if (pagination) {
					sql = sql.concat(CreditCardsModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<CreditCards>(list);
				}
				else {
					list = (List<CreditCards>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the credit cardses from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (CreditCards creditCards : findAll()) {
			remove(creditCards);
		}
	}

	/**
	 * Returns the number of credit cardses.
	 *
	 * @return the number of credit cardses
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_CREDITCARDS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the credit cards persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.ccm.model.CreditCards")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<CreditCards>> listenersList = new ArrayList<ModelListener<CreditCards>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<CreditCards>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(CreditCardsImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_CREDITCARDS = "SELECT creditCards FROM CreditCards creditCards";
	private static final String _SQL_SELECT_CREDITCARDS_WHERE = "SELECT creditCards FROM CreditCards creditCards WHERE ";
	private static final String _SQL_COUNT_CREDITCARDS = "SELECT COUNT(creditCards) FROM CreditCards creditCards";
	private static final String _SQL_COUNT_CREDITCARDS_WHERE = "SELECT COUNT(creditCards) FROM CreditCards creditCards WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "creditCards.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No CreditCards exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No CreditCards exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(CreditCardsPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid", "id"
			});
	private static CreditCards _nullCreditCards = new CreditCardsImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<CreditCards> toCacheModel() {
				return _nullCreditCardsCacheModel;
			}
		};

	private static CacheModel<CreditCards> _nullCreditCardsCacheModel = new CacheModel<CreditCards>() {
			@Override
			public CreditCards toEntityModel() {
				return _nullCreditCards;
			}
		};
}