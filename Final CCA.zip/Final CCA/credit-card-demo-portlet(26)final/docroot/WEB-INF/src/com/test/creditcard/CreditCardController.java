package com.test.creditcard;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.ccm.DTO.CustomerDetails;
import com.ccm.model.BulkUploads;
import com.ccm.model.CreditCards;
import com.ccm.model.Statement;
import com.ccm.model.Transactions;
import com.ccm.service.BulkUploadsLocalServiceUtil;
import com.ccm.service.CreditCardsLocalServiceUtil;
import com.ccm.service.CustomerLocalServiceUtil;
import com.ccm.service.StatementLocalServiceUtil;
import com.ccm.service.TransactionsLocalServiceUtil;
import com.ccm.service.persistence.CreditCardsActionableDynamicQuery;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.PhoneLocalServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.test.model.CustomFileUpload;

import jxl.Cell;
import jxl.JXLException;
import jxl.Sheet;
import jxl.Workbook;

@Controller(value = "CreditCardController")
@RequestMapping("VIEW")
public class CreditCardController {

	@RequestMapping()
	public String handleRenderRequest(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException, PortalException {
		request.getRemoteUser();
		// ThemeDisplay theme = (ThemeDisplay)
		// request.getAttribute(WebKeys.THEME_DISPLAY);
		long userId = 0;
		try {
			userId = Long.parseLong(request.getRemoteUser().trim());
		} catch (Exception e) {
			System.out.println(e);
		}
		Role adminRole = RoleLocalServiceUtil.getRole(10155, "Administrator");
		User userfindby = UserLocalServiceUtil.createUser(-1);
		if (userId > 0) {
			userfindby = UserLocalServiceUtil.getUserById(userId);
		}
		List<Role> roles = userfindby.getRoles();

		if (Validator.isNotNull(roles) && roles.contains(adminRole)) {

			// boolean status
			// =PasswordTrackerLocalServiceUtil.isSameAsCurrentPassword(userfindby.getUserId(),
			return "adminHome";
		} else {
			return "userHome";
		}
	}

	@RenderMapping(params = "action=home")
	public String func(RenderRequest request, RenderResponse response, Model model) {

		return "home";
	}

	@RenderMapping(params = "action=Customers")
	public String CustomersRenderRequest(RenderRequest request, RenderResponse response, ModelMap model)
			throws IOException, PortletException, SystemException, IllegalAccessException, InvocationTargetException, PortalException {

		//List<CustomerDetails> customerList = CustomerLocalServiceUtil.showCustomerList();
		// System.out.println(customerList);
		CustomerDetails c = null;
		List<User> userList = UserLocalServiceUtil.getUsers(-1, -1);
		List<CustomerDetails> custList = new ArrayList<CustomerDetails>();
		for (User user : userList) {
			c = new CustomerDetails();
		//  BeanUtils.copyProperties(c, user.getContact());
			List<Address> addressList = AddressLocalServiceUtil.getAddresses(-1, -1);
			for (Address address : addressList) {
				if(user.getUserId() == address.getUserId()){
					BeanUtils.copyProperties(c, address);
				}
			}
			
			List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);
			for (Phone phone : phoneList) {
				if(user.getUserId() == phone.getUserId()){
					BeanUtils.copyProperties(c, phone);
				}
			}
			
			BeanUtils.copyProperties(c, user);
			custList.add(c);
		}
		model.addAttribute("CustomerList", custList);
		return "customer";
	}

	

	@RenderMapping(params = "action=deleteCustomer")
	public String deleteCustomer(@RequestParam("userId") long userId, ModelMap model)
			throws IOException, PortletException, SystemException {

		try {
//			long contactId = 0;
			long phoneId = 0;
			long addId = 0;

			if (Validator.isNotNull(userId)) {
				User user = UserLocalServiceUtil.getUser(userId);

				/*contactId = user.getContactId();
				if (Validator.isNotNull(contactId)) {
					ContactLocalServiceUtil.deleteContact(contactId);
				}*/

				List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);

				for (int i = 0; i < phoneList.size(); i++) {
					if (phoneList.containsAll(user.getPhones())) {
						phoneId = phoneList.get(i).getPhoneId();
					}
				}
				if (Validator.isNotNull(phoneId)) {
					PhoneLocalServiceUtil.deletePhone(phoneId);
				}

				List<Address> addList = AddressLocalServiceUtil.getAddresses(-1, -1);

				for (int i = 0; i < addList.size(); i++) {
					if (addList.containsAll(user.getAddresses())) {
						addId = addList.get(i).getAddressId();
					}
				}
				if (Validator.isNotNull(addId)) {
					AddressLocalServiceUtil.deleteAddress(addId);
				}

				/*
				 * groupId = user.getGroupId();
				 * if(Validator.isNotNull(groupId)){
				 * GroupLocalServiceUtil.deleteGroup(groupId); }
				 */
				UserLocalServiceUtil.deleteUser(userId);
			}
		} catch (PortalException e) {

			e.printStackTrace();
		}

		List<CustomerDetails> customerList = CustomerLocalServiceUtil.showCustomerList();
		// System.out.println(customerList);
		model.addAttribute("CustomerList", customerList);
		return "customer";
	}

	@RenderMapping(params = "action=Transactions")
	public String renderMethod(RenderRequest request, RenderResponse response, ModelMap model)
			throws IOException, PortletException, SystemException {
		List<Transactions> transMainList = TransactionsLocalServiceUtil.getTransactionses(-1, -1);
		// System.out.println(transMainList);
		model.addAttribute("TransactionList", transMainList);
		return "transaction";
	}

	@RenderMapping(params = "action=Statements")
	public String StatementsRenderMethod(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		List<Statement> statementList = StatementLocalServiceUtil.getStatements(-1, -1);
		model.addAttribute("StatementList", statementList);
		return "statement";
	}

	@RenderMapping(params = "action=editCustomer")
	public String editCustomer(@RequestParam("userId") long userId, RenderRequest request, RenderResponse response,
			Model model) throws IOException, PortletException, SystemException, PortalException, IllegalAccessException, InvocationTargetException {

		System.out.println("UserId " + userId);

		User user = UserLocalServiceUtil.getUser(userId);
		CustomerDetails cd = new CustomerDetails();
		BeanUtils.copyProperties(cd, user);
		
		long addressId = 0;
		List<Address> addressList = AddressLocalServiceUtil.getAddresses(-1, -1);
		for (Address address : addressList) {
			if (address.getUserId() == userId) {
				addressId = address.getAddressId();
				Address add = AddressLocalServiceUtil.getAddress(addressId);
				if (add != null) {
					BeanUtils.copyProperties(cd, add);
				}
			}
		}
		
		long phoneId = 0;
		Phone phone1 = null;
		List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);
		for (Phone phone : phoneList) {
			if (phone.getUserId() == userId) {
				phoneId = phone.getPhoneId();
				phone1 = PhoneLocalServiceUtil.getPhone(phoneId);
				if (phone1 != null) {
					BeanUtils.copyProperties(cd, phone1);
				}
			} 
		}		
		model.addAttribute("CustomerDetails", cd);

		return "editCustomer";
	}
	
	@RenderMapping(params = "action=userProfile")
	public String userProfileRenderMethod(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException, PortalException, IllegalAccessException,
			InvocationTargetException {

		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		User user = UserLocalServiceUtil.getUserById(themeDisplay.getUserId());
		CustomerDetails cd = new CustomerDetails();
		BeanUtils.copyProperties(cd, user);

		long addressId = 0;
		List<Address> addressList = AddressLocalServiceUtil.getAddresses(-1, -1);
		for (Address address : addressList) {
			if (address.getUserId() == themeDisplay.getUserId()) {
				addressId = address.getAddressId();
				Address add = AddressLocalServiceUtil.getAddress(addressId);
				if (add != null) {
					BeanUtils.copyProperties(cd, add);
				}
			}
		}
		
		long phoneId = 0;
		Phone phone1 = null;
		List<Phone> phoneList = PhoneLocalServiceUtil.getPhones(-1, -1);
		for (Phone phone : phoneList) {
			if (phone.getUserId() == themeDisplay.getUserId()) {
				phoneId = phone.getPhoneId();
				phone1 = PhoneLocalServiceUtil.getPhone(phoneId);
				if (phone1 != null) {
					BeanUtils.copyProperties(cd, phone1);
				}
			} 
		}
		/*if(phone1 == null){
			cd.setNumber(null);
		}*/
		
		model.addAttribute("user", cd);
		return "userProfile";
	}

	@RenderMapping(params = "action=userTransactions")
	public String userTransRenderMethod(RenderRequest request, RenderResponse response, ModelMap model)
			throws IOException, PortletException, SystemException {

		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);

		List<Transactions> transMainList = TransactionsLocalServiceUtil.getUserTransactions(themeDisplay.getUserId());
		model.addAttribute("TransactionList", transMainList);

		return "userTransaction";
	}

	@RenderMapping(params = "action=userStatements")
	public String userStateRenderMethod(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		List<CreditCards> cardList = CreditCardsLocalServiceUtil.getCreditCardHolder(themeDisplay.getUserId());
		for (CreditCards card : cardList) {
			List<Statement> statementList = StatementLocalServiceUtil.getUserStatements(card.getId());
			model.addAttribute("StatementList", statementList);
		}

		return "userStatement";
	}

	@RenderMapping(params = "action=BulkUploads")
	public String BulkUploadsRenderRequest(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		List<BulkUploads> uploadList = BulkUploadsLocalServiceUtil.getBulkUploadses(-1, -1);
		// System.out.println(uploadList);

		model.addAttribute("UploadList", uploadList);
		return "bulkUpload";
	}

	@RenderMapping(params = "action=addCustomerView")
	public String addCustomerView(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		return "addCustomer";

	}

	@RenderMapping(params = "action=addCreditCardView")
	public String addCreditCardView(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		List<User> userList = UserLocalServiceUtil.getUsers(-1, -1);
		Map<Long, String> cardHolder = new HashMap<Long, String>();

		for (User holder : userList) {
			cardHolder.put(holder.getUserId(), holder.getFirstName());
		}
		model.addAttribute("cardHolder", cardHolder);

		return "addCreditCard";
	}

	@RenderMapping(params = "action=showCreditCardView")
	public String showCreditCardView(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		List<CreditCards> CreditCardList = CreditCardsLocalServiceUtil.getCreditCardses(-1, -1);
		model.addAttribute("CreditCardList", CreditCardList);
		return "showCreditCards";
	}

	@RenderMapping(params = "action=addTransactionView")
	public String renderOneMethod(RenderRequest request, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {
		List<User> userList = UserLocalServiceUtil.getUsers(-1, -1);
		Map<Long, String> cardHolder = new HashMap<Long, String>();
		cardHolder.put(Long.valueOf(-1), "Select Customer");
		for (User holder : userList) {
			cardHolder.put(holder.getUserId(), holder.getFirstName());
		}
		model.addAttribute("cardHolder", cardHolder);

		Map<Long, String> creditCard = new HashMap<Long, String>();
		creditCard.put(Long.valueOf(-1), "Select Credit Card");
		model.addAttribute("CreditCards", creditCard);
		return "AddTransaction";
	}

	@RenderMapping(params = "action=renderOne")
	public String showCreditCardListT(@RequestParam("userId") long userId, RenderRequest request,
			RenderResponse response, ModelMap model) throws IOException, PortletException, SystemException {
		// System.out.println(userId);
		List<CreditCards> creditCardList1 = CreditCardsLocalServiceUtil.getCreditCardHolder(userId);
		// System.out.println("After getting Customer Name");
		// System.out.println(creditCardList1.size());

		Map<Long, String> creditCard1 = new HashMap<Long, String>();

		for (CreditCards card : creditCardList1) {
			creditCard1.put(card.getId(), card.getCardNumber());
		}
		model.addAttribute("CreditCards", creditCard1);
		return "AddTransaction";
	}

	@RenderMapping(params = "action=uploadCustomerView")
	public String uploadCustomerView(RenderRequest render, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

	/*	List<User> userList = UserLocalServiceUtil.getUsers(-1, -1);
		Map<Long, String> cardHolder = new HashMap<Long, String>();
		cardHolder.put(Long.valueOf(-1), "Select Customer");
		for (User holder : userList) {
			cardHolder.put(holder.getUserId(), holder.getFirstName());
		}
		model.addAttribute("cardHolder", cardHolder);

		Map<Long, String> creditCard = new HashMap<Long, String>();
		creditCard.put(Long.valueOf(-1), "Select Credit Card");
		model.addAttribute("CreditCards", creditCard);*/
		model.addAttribute("customFileUpload", new CustomFileUpload());
		return "uploadCustomer";
	}

	/*@RenderMapping(params = "action=selectCreditCardUploadCust")
	public String showCreditCardListUploadCust(@RequestParam("userId") long userId, RenderRequest request,
			RenderResponse response, ModelMap model) throws IOException, PortletException, SystemException {
		// System.out.println(userId);
		List<CreditCards> creditCardList1 = CreditCardsLocalServiceUtil.getCreditCardHolder(userId);
		// System.out.println("After getting Customer Name");
		// System.out.println(creditCardList1.size());

		Map<Long, String> creditCard1 = new HashMap<Long, String>();

		for (CreditCards card : creditCardList1) {
			creditCard1.put(card.getId(), card.getCardNumber());
		}
		model.addAttribute("CreditCards", creditCard1);
		return "uploadCustomer";
	}
*/
	@RenderMapping(params = "action=uploadTranView")
	public String uploadTranView(RenderRequest render, RenderResponse response, Model model)
			throws IOException, PortletException, SystemException {

		List<User> userList = UserLocalServiceUtil.getUsers(-1, -1);
		Map<Long, String> cardHolder = new HashMap<Long, String>();
		cardHolder.put(Long.valueOf(-1), "Select Customer");
		for (User holder : userList) {
			cardHolder.put(holder.getUserId(), holder.getFirstName());
		}
		model.addAttribute("cardHolder", cardHolder);

		Map<Long, String> creditCard = new HashMap<Long, String>();
		creditCard.put(Long.valueOf(-1), "Select Credit Card");
		model.addAttribute("CreditCards", creditCard);
		model.addAttribute("customFileUpload", new CustomFileUpload());
		return "uploadTransaction";
	}

	@RenderMapping(params = "action=selectCreditCardUploadTran")
	public String showCreditCardListUploadTran(@RequestParam("userId") long userId, RenderRequest request,
			RenderResponse response, ModelMap model) throws IOException, PortletException, SystemException {
		// System.out.println(userId);
		List<CreditCards> creditCardList1 = CreditCardsLocalServiceUtil.getCreditCardHolder(userId);
		// System.out.println("After getting Customer Name");
		// System.out.println(creditCardList1.size());

		Map<Long, String> creditCard1 = new HashMap<Long, String>();

		for (CreditCards card : creditCardList1) {
			creditCard1.put(card.getId(), card.getCardNumber());
		}
		model.addAttribute("CreditCards", creditCard1);
		return "uploadTransaction";
	}

	@ModelAttribute("CreditCards")
	public CreditCards LoadEmptyModelBean() {
		CreditCards holder = CreditCardsLocalServiceUtil.createCreditCards(-1);

		return holder;
	}

	@ModelAttribute("User")
	public User LoadEmptyUserBean() {
		User user = UserLocalServiceUtil.createUser(-1);
		return user;
	}

	@ModelAttribute("Transactions")
	public Transactions LoadEmptyTransModelBean() {
		Transactions trans = TransactionsLocalServiceUtil.createTransactions(-1);

		return trans;
	}

	@ModelAttribute("BulkUploads")
	public BulkUploads LoadEmptyBulkUploadsModelBeam() {
		BulkUploads upload = BulkUploadsLocalServiceUtil.createBulkUploads(-1);
		return upload;
	}

	@ModelAttribute("CustomerDetails")
	public CustomerDetails LoadEmptyCustModelBean() {
		return new CustomerDetails();
	}

	/*
	 * @ActionMapping(params = "action=loginAs") public String
	 * submit(@ModelAttribute("User") User user, ActionRequest request,
	 * ActionResponse response, Model model) throws SystemException,
	 * PortalException, ServletException {
	 * 
	 * ThemeDisplay themeDisplay = (ThemeDisplay)
	 * request.getAttribute(WebKeys.THEME_DISPLAY);
	 * 
	 * if (user != null && user.getEmailAddress() != null & user.getPassword()
	 * != null) {
	 * 
	 * Role adminRole = RoleLocalServiceUtil.getRole(10155, "Administrator");
	 * User userfindby = UserLocalServiceUtil.getUserByEmailAddress(10155,
	 * user.getEmailAddress()); List<Role> roles = userfindby.getRoles();
	 * userfindby.getRoleIds(); userfindby.getScreenName(); if
	 * (Validator.isNotNull(roles) && roles.contains(adminRole)) {
	 * 
	 * if (userfindby.getPassword().equals(user.getPassword())) { return
	 * "adminHome"; }
	 * 
	 * // boolean status = //
	 * PasswordTrackerLocalServiceUtil.isSameAsCurrentPassword(userfindby.
	 * getUserId(), // user.getPassword()); return "adminHome"; } else { return
	 * "userHome"; } } else { model.addAttribute("error", "Please enter Details"
	 * ); return "login"; }
	 * 
	 * }
	 */

	@RenderMapping(params = "action=addCustomers")
	public void addCustomers(@ModelAttribute("CustomerDetails") CustomerDetails cust1, RenderRequest request,
			RenderResponse response, ModelMap model) throws IOException, PortletException, SystemException {

		try {
			ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
//			System.out.println(cust1.getUserId());
			CustomerLocalServiceUtil.addCustomerDetails(cust1, themeDisplay);
			CustomerLocalServiceUtil.addCustomerAddress(cust1);
			CustomerLocalServiceUtil.addCustomerPhone(cust1);			
//			CustomerLocalServiceUtil.addCustomerContact(cust1);
	
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception");
		}
	}

	@ActionMapping(params = "action=addTransaction")
	public void addTransaction(@ModelAttribute("Transactions") Transactions trans1, ModelMap model)
			throws IOException, PortletException, SystemException {

		try {

			long id = CounterLocalServiceUtil.increment();
			Date transactionDate = new Date();
			Transactions trans = TransactionsLocalServiceUtil.createTransactions(id);
			trans.setUserId(trans1.getUserId());
			trans.setCreditCardId(trans1.getCreditCardId());
			trans.setAmount(trans1.getAmount());
			trans.setDescription(trans1.getDescription());
			trans.setTransactionDate(transactionDate);
			TransactionsLocalServiceUtil.addTransactions(trans);

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("Exception");
		}
	}

	@ActionMapping(params = "action=addCreditCards")
	public void addCreditCard(@ModelAttribute("CreditCards") CreditCards holder1, ModelMap model)
			throws IOException, PortletException, SystemException {

		try {

			// System.out.println(holder1.getUserId());
			long id = CounterLocalServiceUtil.increment();
			CreditCards holder = CreditCardsLocalServiceUtil.createCreditCards(id);
			holder.setUserId(holder1.getUserId());
			holder.setCardNumber(holder1.getCardNumber());
			holder.setNameOnCard(holder1.getNameOnCard());
			holder.setCvv(holder1.getCvv());
			holder.setCreditLimit(holder1.getCreditLimit());
			holder.setValidFromDate(holder1.getValidFromDate());
			holder.setValidToDate(holder1.getValidToDate());
			CreditCardsLocalServiceUtil.addCreditCards(holder);

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("Exception");
		}
	}

	@ActionMapping(params = "action=addBulkTransUploads")
	public void addTransBulkUpload(@ModelAttribute("BulkUploads") BulkUploads file, ActionRequest request,
			ActionResponse response, ModelMap model,
			@RequestParam(value = "multipartFile", required = false) CommonsMultipartFile multipartFile)
			throws IOException, PortletException, SystemException, JXLException {
		long startTime = System.currentTimeMillis();
		int countUploads = 0;
		int totalRecords = 0;
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);

		if (Validator.isNotNull(multipartFile)) {
			File file2 = new File("temp.xls");
			BufferedOutputStream bufferedStream = new BufferedOutputStream(new FileOutputStream(file2));
			byte b[] = multipartFile.getBytes();
			bufferedStream.write(b);
			bufferedStream.flush();
			Workbook w = Workbook.getWorkbook(file2);
			Sheet sheet = w.getSheet(0);
			totalRecords = sheet.getRows();
			for (int i = 0; i < sheet.getRows(); i++) {

				Cell[] cell = sheet.getRow(i);
				Transactions transactions = TransactionsLocalServiceUtil
						.createTransactions(CounterLocalServiceUtil.increment());
				transactions.setUserId(file.getUserId());
				transactions.setCreditCardId(file.getCreditCardId());
				transactions.setAmount(Double.parseDouble(cell[0].getContents().toString()));
				transactions.setDescription(cell[1].getContents().toString());
				transactions.setTransactionDate(Calendar.getInstance().getTime());
				if (file.getCreditCardId() != 0) {
					TransactionsLocalServiceUtil.addTransactions(transactions);
					countUploads++;
				}

			}

			bufferedStream.close();
			long endTime = System.currentTimeMillis();
			long totalTime = endTime - startTime;
			BulkUploads upload = BulkUploadsLocalServiceUtil.createBulkUploads(CounterLocalServiceUtil.increment());
			upload.setUploadDate(new Date());
			upload.setTimeTaken(totalTime);
			upload.setTotalRecords(totalRecords);
			upload.setSuccessRecords(countUploads);
			upload.setFailedRecords(totalRecords - countUploads);
			upload.setFileName(multipartFile.getOriginalFilename());
			upload.setUserId(themeDisplay.getUserId());
//			upload.setCreditCardId(file.getCreditCardId());

			// upload.setUploadDate(file.getUploadDate());
			BulkUploadsLocalServiceUtil.addBulkUploads(upload);

		}
	}

	@ActionMapping(params = "action=addBulkCustUploads")
	public void addCustBulkUpload(@ModelAttribute("BulkUploads") BulkUploads file, ActionRequest request,
			ActionResponse response, ModelMap model,
			@RequestParam(value = "multipartFile", required = false) CommonsMultipartFile multipartFile)
			throws IOException, PortletException, SystemException, JXLException, ParseException {
		long startTime = System.currentTimeMillis();
		int countUploads = 0;
		int totalRecords = 0;

		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);

//		System.out.println(file.getCreditCardId());
		if (Validator.isNotNull(multipartFile)) {
			File file2 = new File("temp.xls");
			BufferedOutputStream bufferedStream = new BufferedOutputStream(new FileOutputStream(file2));
			byte b[] = multipartFile.getBytes();
			bufferedStream.write(b);
			bufferedStream.flush();
			Workbook w = Workbook.getWorkbook(file2);
			Sheet sheet = w.getSheet(0);
			totalRecords = sheet.getRows();
			for (int i = 0; i < sheet.getRows(); i++) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Cell[] cell = sheet.getRow(i);
				CustomerDetails customers = new CustomerDetails();
				customers.setFirstName(cell[0].getContents().toString());
				customers.setLastName(cell[1].getContents().toString());
				customers.setScreenName(cell[2].getContents().toString());
				customers.setEmailAddress(cell[3].getContents().toString());
				customers.setNumber(cell[4].getContents().toString());
				customers.setStreet1(cell[5].getContents().toString());
				customers.setCity(cell[6].getContents().toString());
				customers.setZip(cell[7].getContents().toString());
				customers.setBirthday(dateFormat.parse(cell[8].getContents().toString()));

				if (themeDisplay.getUserId() != 0) {
					CustomerLocalServiceUtil.addCustomerDetails(customers, themeDisplay);
					CustomerLocalServiceUtil.addCustomerAddress(customers);
//					CustomerLocalServiceUtil.addCustomerContact(customers);
					CustomerLocalServiceUtil.addCustomerPhone(customers);
					countUploads++;
				}
			}

			bufferedStream.close();
			long endTime = System.currentTimeMillis();
			long totalTime = endTime - startTime;
			BulkUploads upload = BulkUploadsLocalServiceUtil.createBulkUploads(CounterLocalServiceUtil.increment());
			upload.setUploadDate(new Date());
			upload.setTimeTaken(totalTime);
			upload.setTotalRecords(totalRecords);
			upload.setSuccessRecords(countUploads);
			upload.setFailedRecords(totalRecords - countUploads);
			upload.setFileName(multipartFile.getOriginalFilename());
			upload.setUserId(themeDisplay.getUserId());
//			upload.setCreditCardId(file.getCreditCardId());

			// upload.setUploadDate(file.getUploadDate());
			BulkUploadsLocalServiceUtil.addBulkUploads(upload);

		}
	}
}