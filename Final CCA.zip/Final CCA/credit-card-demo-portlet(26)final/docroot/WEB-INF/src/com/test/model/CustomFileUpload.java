package com.test.model;

import org.springframework.web.multipart.MultipartFile;

public class CustomFileUpload {

	private long userId;
	private long creditCardId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getCreditCardId() {
		return creditCardId;
	}

	public void setCreditCardId(long creditCardId) {
		this.creditCardId = creditCardId;
	}
	// getter and setter methods

}