package com.test.transaction;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

@Controller(value = "AddTransactionPortlet")
@RequestMapping("VIEW")
public class AddTransactionPortlet {
 
	@RenderMapping(params = "action=home")
	public String method(RenderRequest request, RenderResponse response){
		return "render1";
	}
	
	@RenderMapping(params = "action=renderOne")
	public String renderOneMethod(RenderRequest request, RenderResponse response, Model model) {
		return "default";
	}
	
	@RenderMapping
	public String fun(RenderRequest request, RenderResponse response){
		return "render1";
	}

}
