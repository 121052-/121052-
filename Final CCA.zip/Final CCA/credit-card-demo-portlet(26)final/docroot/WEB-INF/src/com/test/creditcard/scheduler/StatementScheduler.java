package com.test.creditcard.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.ccm.model.Transactions;
import com.ccm.service.StatementLocalService;
import com.ccm.service.TransactionsLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.Validator;

public class StatementScheduler implements MessageListener {

	@Override
	public void receive(Message arg0) throws MessageListenerException {
		System.out.println("Hello Shreeya !");
		Calendar calendar = Calendar.getInstance();
		System.out.println("Start Date :" + calendar.getTime());
		Date toDate = calendar.getTime();
		calendar.add(Calendar.MONTH, -1);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		System.out.println("End Date :" + calendar.getTime());
		Date fromDate = calendar.getTime();

//		try {
//			List<Transactions> transMainList = TransactionsLocalServiceUtil.getTransactionses(-1, -1);
//			List<Transactions> statementList = new ArrayList<Transactions>();
//			for (Transactions t : transMainList) {
//				statementList.add(t);
//			}
//			System.out.println("In database, TransactionDate is: ");
//			for (Transactions t1 : statementList) {
//				System.out.println(t1.getTransactionDate());
//			}
//
//		} catch (SystemException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		List<Transactions> statementList1 = TransactionsLocalServiceUtil.getAllTransactionBetweenDate(fromDate, toDate);
		//Map creditcard id with trans id
		System.out.println("Dynamic Query returns: statementList1 size: " + statementList1.size());
		System.out.println(statementList1);

	}
}
