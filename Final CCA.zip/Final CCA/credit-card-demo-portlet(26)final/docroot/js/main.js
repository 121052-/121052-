function fun() {
	console.log("I m in the fun()");
	var formData = new FormData($('form')[0]);
	// formData.append( "fileName", $("input[name=fileName]").files[0]);
	var fileName = $('#fileName').val();
	console.log("filename " + fileName);
	console.log("form data " + formData);
	$.ajax({
		url : "${uploadTransactionsActionURL}",
		data : "fileName=" + fileName,
		processData : false,
		contentType : false,
		type : 'POST',
		success : function(data) {
			alert(data);
		},
		error : function(err) {
			alert(err);
		}
	});
}